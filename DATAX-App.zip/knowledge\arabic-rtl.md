keywords: عرب|rtl|arabic|خط|font|لغة|ترجمة|translate
# Arabic / RTL web tips
- <html lang="ar" dir="rtl">. Use logical CSS (margin-inline-start, padding-inline, text-align:start, inset-inline-end) so layouts flip automatically.
- Flex rows reverse automatically in RTL. Icons/arrows that imply direction must be mirrored (transform:scaleX(-1)).
- Fonts: Segoe UI/Tahoma safe; Google Fonts good Arabic choices: Cairo, Tajawal, Almarai, IBM Plex Sans Arabic. Line-height 1.7-1.9 for Arabic body text.
- Mixed text: wrap English/code in <bdi> or dir="auto"/dir="ltr" so punctuation doesn't jump. Numbers: Arabic-Indic or Western are both fine; stay consistent.
- Bilingual sites: keep texts in a JS object {ar:{...}, en:{...}}, toggle document.documentElement.lang/dir and re-render text; remember choice in localStorage.
- Canvas/ffmpeg drawtext don't shape Arabic reliably: render Arabic text with HTML/CSS (make_cover / html_to_image) instead.

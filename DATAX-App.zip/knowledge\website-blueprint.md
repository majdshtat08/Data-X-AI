keywords: موقع|website|landing|هبوط|portfolio|شركة|متجر|مدونة|\bsite\b|احترافي
# Building a professional website (workflow)
1. Call make_website(name, tagline, about, features, theme, lang) FIRST: it creates index.html + style.css + script.js with a polished responsive design. Then customize with edit_file/write_file (add sections, change text/colors), then open_target index.html.
2. Typical sections: sticky nav, hero (headline + one clear call-to-action button), features/services cards, about, gallery/portfolio, testimonials, pricing, FAQ, contact, footer.
3. Design rules: 1 main + 1 accent color, dark or light consistently, generous spacing, max 2 fonts, big readable headings, real content (no lorem ipsum), consistent border-radius, subtle hover/scroll animations.
4. Quality checklist: works on phone width (360px); no horizontal scroll; every image has alt; buttons look clickable; links work; page title set; test by opening index.html.
5. Keep it static (HTML/CSS/JS only) so it can be hosted free on GitHub Pages / Netlify. Put the files in one folder with index.html at the root.

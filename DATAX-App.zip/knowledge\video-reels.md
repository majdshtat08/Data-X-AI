keywords: reel|ريل|فيديو|video|tiktok|تيك|مونتاج|ffmpeg|short|youtube|يوتيوب|cover|غلاف|thumbnail|بوستر
# Reels / video / cover tips
- Formats: Reels/TikTok/Shorts 1080x1920 (9:16), 15-30s best; Instagram post 1080x1080 or 1080x1350; YouTube video 1920x1080, thumbnail 1280x720.
- Tools here: make_reel(items=[images/videos], seconds_per_image, audio) builds a vertical reel with zoom motion; video_to_reel crops a landscape video to 9:16; video_trim cuts a section; make_cover makes a branded cover/poster; ai_image generates art (English prompt); ffmpeg for custom edits.
- Hook in first 2 seconds, big readable text (safe margins ~10%), one idea per scene (2-3s per image), trending sound, end with call-to-action. Captions: short + 3-5 relevant hashtags.
- ffmpeg recipes: speed up -vf setpts=0.5*PTS; mute -an; extract audio -vn -c:a mp3 out.mp3; resize -vf scale=1080:-2; compress -crf 28 -preset veryfast; GIF from video -vf fps=12,scale=480:-1; add music -i v.mp4 -i a.mp3 -shortest -c:v copy -c:a aac out.mp4.

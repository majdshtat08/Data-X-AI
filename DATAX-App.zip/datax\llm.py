"""عميل Ollama: بث مباشر، اختيار تلقائي للنموذج، وتحليل أوامر الأدوات المكتوبة كنص."""
import json, os, re, shutil, subprocess, time, urllib.error, urllib.request
from . import config
BIG = ["qwen2.5:7b", "qwen3:8b", "llama3.1:8b", "qwen2.5:3b", "llama3.2:3b", "qwen2.5:1.5b"]
SMALL = ["qwen2.5:3b", "llama3.2:3b", "qwen2.5:7b", "qwen3:8b", "llama3.1:8b", "qwen2.5:1.5b"]

def ram_gb():
    try:
        if os.name == "nt":
            import ctypes
            class M(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("p", ctypes.c_ulong), ("total", ctypes.c_ulonglong)] + [(f"x{i}", ctypes.c_ulonglong) for i in range(5)]
            m = M(); m.l = ctypes.sizeof(M); ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)); return m.total / 2**30
        return int(open("/proc/meminfo").read().split()[1]) / 2**20
    except Exception: return 8
def recommended(): return "qwen2.5:7b" if ram_gb() >= 24 else "qwen2.5:3b"
STATE, _cache = {"msg": ""}, {"t": 0, "v": None}

def _req(path, body=None, timeout=10):
    r = urllib.request.Request(config.load()["ollama_url"] + path, json.dumps(body).encode() if body is not None else None, {"Content-Type": "application/json"})
    return urllib.request.urlopen(r, timeout=timeout)
def models():
    if _cache["v"] is not None and time.time() - _cache["t"] < 3: return _cache["v"]
    try: v = [m["name"] for m in json.loads(_req("/api/tags", timeout=4).read())["models"]]
    except Exception: v = None  # None = Ollama لا يعمل
    _cache.update(t=time.time(), v=v); return v
def pick(s=None):
    s = s or config.load(); ms = models() or []
    if s["model"] != "auto" and s["model"] in ms: return s["model"]
    local = [m for m in ms if not m.endswith(":cloud")]
    for p in (BIG if ram_gb() >= 24 else SMALL):
        if p in local: return p
    return (local or ms or [None])[0]
def warmup():
    try: m = pick(); m and _req("/api/generate", {"model": m, "keep_alive": "30m", "options": {"num_ctx": config.load()["ctx"]}}, 300).read()
    except Exception: pass

def stream(model, messages, schemas, system, ctx):
    body = {"model": model, "stream": True, "keep_alive": "30m", "options": {"num_ctx": ctx, "temperature": 0.3, "num_predict": 2500},
            "messages": [{"role": "system", "content": system}] + messages}
    if schemas: body["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}} for t in schemas]
    with _req("/api/chat", body, 900) as r:
        for line in r:
            if not line.strip(): continue
            d = json.loads(line)
            if d.get("error"): raise RuntimeError(d["error"])
            yield d

def text_calls(text, known):
    """بعض النماذج تكتب أمر الأداة كنص JSON بدل الشكل الرسمي؛ نلتقطه هنا."""
    calls, clean = [], text
    for m in re.finditer(r"<tool_call>\s*(\{.*?\})\s*</tool_call>|(\{\s*\"name\"\s*:.*?\}\s*\})", text, re.S):
        try: d = json.loads(m.group(1) or m.group(2))
        except Exception: continue
        if d.get("name") in known:
            calls.append({"function": {"name": d["name"], "arguments": d.get("arguments") or d.get("parameters") or {}}}); clean = clean.replace(m.group(0), "")
    return calls, clean.strip()

NOWIN = config.NOWIN
def ensure_ollama():
    if models() is not None: return True
    exe = config.find_exe("ollama")
    if not exe: return False
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NOWIN)
    for _ in range(40):
        time.sleep(0.5); _cache["v"] = None
        if models() is not None: return True
    return False
def winget(pid, label):
    if not shutil.which("winget"): return False
    STATE["msg"] = f"تثبيت {label} (مرة واحدة)…"
    try: subprocess.run(["winget", "install", "-e", "--id", pid, "--silent", "--accept-source-agreements", "--accept-package-agreements"], creationflags=NOWIN, timeout=1800, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return True
    except Exception: return False
def background_setup():
    """أول تشغيل: يثبّت Ollama وFFmpeg إن لزم، ينزّل النموذج المناسب لجهازك، ويحمّله للذاكرة."""
    try:
        if not config.find_exe("ollama"): winget("Ollama.Ollama", "محرك الذكاء الاصطناعي")
        if not ensure_ollama(): STATE["msg"] = "ثبّت Ollama من ollama.com ثم أعد فتح DATA X"; return
        exe, want = config.find_exe("ollama"), recommended()
        if config.load()["model"] == "auto" and want not in (models() or []):
            STATE["msg"] = f"تنزيل {want}…"
            p = subprocess.Popen([exe, "pull", want], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=NOWIN)
            while (b := os.read(p.stdout.fileno(), 512)):
                m = re.findall(rb"(\d+)%", b)
                if m: STATE["msg"] = f"تنزيل {want} {m[-1].decode()}%"
            p.wait(); _cache["v"] = None
        STATE["msg"] = ""; warmup()
        if not config.find_exe("ffmpeg"): winget("Gyan.FFmpeg", "FFmpeg للمونتاج"); STATE["msg"] = ""
    except Exception as e: STATE["msg"] = ""; print("setup:", e)

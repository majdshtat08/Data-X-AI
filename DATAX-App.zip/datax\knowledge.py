"""قاعدة معرفة: ملفات knowledge/*.md (السطر الأول keywords: regex). تُحقن المقاطع المناسبة للطلب في تعليمات النموذج."""
import re
from .config import HOME, RES
_D = None
def _load():
    out = []
    for d in (RES / "knowledge", HOME / "knowledge"):
        for f in (sorted(d.glob("*.md")) if d.exists() else []):
            t = f.read_text("utf-8"); m = re.match(r"keywords:\s*(.+)\n", t)
            if m: out.append((re.compile(m.group(1).strip(), re.I), t[m.end():].strip()))
    return out
def lookup(text, limit=2200):
    global _D; _D = _D if _D is not None else _load()
    hits = sorted(((len(rx.findall(text)), b) for rx, b in _D if rx.search(text)), key=lambda x: -x[0])[:2]; out, n = [], 0
    for _, b in hits:
        b = b[:max(0, limit - n - (2 if out else 0))]
        if b: out.append(b); n += len(b) + (2 if out else 0)
    return "\n\n".join(out)

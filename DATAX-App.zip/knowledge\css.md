keywords: css|تصميم|ستايل|style|layout|flex|grid|responsive|animation|dark|اني?ميشن|رسبونسف|ألوان|الوان
# CSS essentials
- Reset: *{box-sizing:border-box;margin:0}. Variables: :root{--c1:#3b82f6;--bg:#0b1020} used as var(--c1).
- Flex (1D): display:flex; gap:16px; align-items:center; justify-content:space-between; flex-wrap:wrap.
- Grid (2D): display:grid; grid-template-columns:repeat(auto-fit,minmax(250px,1fr)); gap:20px  -> responsive without media queries.
- Responsive: mobile-first; @media (max-width:720px){...}; fluid type font-size:clamp(2rem,5vw,4rem); max-width on containers; images max-width:100%.
- Modern look: gradient backgrounds linear-gradient(135deg,#3b82f6,#8b5cf6); border-radius:16px; box-shadow:0 10px 30px #0006; backdrop-filter:blur(12px); gradient text via background-clip:text;color:transparent.
- Motion: transition:transform .25s; :hover{transform:translateY(-4px)}; @keyframes fade{from{opacity:0}to{opacity:1}} animation:fade .6s both. Respect @media (prefers-reduced-motion:reduce).
- Dark mode: @media (prefers-color-scheme:dark){:root{...}}. Sticky header: position:sticky;top:0. Center: margin-inline:auto.
- Use logical props for RTL/LTR: margin-inline-start, padding-inline, inset-inline-end, text-align:start.
- Fonts: font-family:"Segoe UI",Tahoma,Arial,sans-serif (safe for Arabic). Keep contrast high; spacing scale 8/16/24/48px.

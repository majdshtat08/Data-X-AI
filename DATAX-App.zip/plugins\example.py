# أي ملف .py هنا يُحمّل تلقائياً كأداة جديدة
@tool("word_count", "عدّ كلمات ملف", {"path": S("المسار")}, ["path"])
def word_count(path): return str(len(P(path).read_text("utf-8").split()))

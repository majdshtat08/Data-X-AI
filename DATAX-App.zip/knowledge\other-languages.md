keywords: java\b|c\+\+|c#|csharp|php|\bsql\b|typescript|rust|golang|kotlin|swift|bash|powershell|sqlite|mysql|لغة|لغات|برمجة
# Quick language guide
- SQL: SELECT col FROM t WHERE x>1 ORDER BY y LIMIT 10; INSERT INTO t(a,b) VALUES(1,2); UPDATE t SET a=1 WHERE id=3; DELETE ... WHERE (never without WHERE); JOIN t2 ON t.id=t2.t_id; GROUP BY + COUNT/SUM/AVG; CREATE TABLE t(id INTEGER PRIMARY KEY, name TEXT).
- TypeScript: JS + types: let n: number; interface User{id:number;name:string}; function f(x:string):void; compile with tsc.
- Java: class Main{ public static void main(String[] a){ System.out.println("hi"); } } ; C#: Console.WriteLine; C++: #include <iostream> std::cout << "hi"; 
- PHP: <?php echo "hi"; ?> runs on a server; Kotlin/Swift: modern Android/iOS apps; Go/Rust: fast compiled tools/servers.
- PowerShell (Windows): Get-ChildItem, Get-Content f, Set-Location, Copy-Item, Remove-Item (dangerous), $env:USERPROFILE. Bash: ls, cd, cat, grep, chmod.
- Choosing: websites=HTML/CSS/JS; scripts/automation/AI=Python; Android=Kotlin; Windows apps=C#; databases=SQL; games=Unity(C#)/Godot/JS canvas.

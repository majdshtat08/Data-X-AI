keywords: error|خطأ|خطا|bug|مشكلة|لا يعمل|مش شغال|fix|أصلح|اصلح|debug|exception|traceback|crash
# Debugging method
1. Read the error message fully: the last line says WHAT, the line number says WHERE (Python: read traceback bottom-up; JS: open DevTools Console with F12).
2. Reproduce with the smallest input; print/console.log intermediate values to find where reality differs from expectation.
3. Common causes: typo in a name; wrong file path (use absolute paths or the working folder); missing dependency/import; wrong type (string vs number); undefined/None value; off-by-one; missing await/async; CORS/network errors in fetch; encoding issues (use utf-8).
4. Fix one thing at a time, re-run, verify the actual result (read the file / run the code) before saying it works.
5. If stuck: simplify, search the exact error text, check docs (developer.mozilla.org for web, docs.python.org for Python).

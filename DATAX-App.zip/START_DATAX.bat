@echo off
chcp 65001 >nul
cd /d "%~dp0"
title DATA X
set NEED=0
where python >nul 2>nul || ( echo Installing Python... & winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements & set NEED=1 )
where ollama >nul 2>nul || ( echo Installing Ollama... & winget install -e --id Ollama.Ollama --accept-source-agreements --accept-package-agreements & set NEED=1 )
where ffmpeg >nul 2>nul || ( echo Installing FFmpeg... & winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements & set NEED=1 )
if "%NEED%"=="1" (
  echo.
  echo Installation finished. Close this window and double-click START_DATAX.bat again.
  pause
  exit /b
)
if not exist ".ready" (
  python -m pip install -q -r requirements.txt
  powershell -NoProfile -ExecutionPolicy Bypass -File make_shortcut.ps1
  echo ok>.ready
  echo.
  echo A "DATA X" shortcut was added to your Desktop. Next time just use it.
)
echo Starting DATA X... ^(the AI model downloads automatically the first time^)
python run.py
pause

keywords: html|موقع|صفحة|website|web ?page|semantic|form|seo|meta
# HTML5 essentials
- Skeleton: <!DOCTYPE html>, <html lang dir>, <meta charset="utf-8">, <meta name="viewport" content="width=device-width, initial-scale=1">, <title>, then <body>.
- Semantic tags: header, nav, main, section, article, aside, footer, figure/figcaption. One <h1> per page; headings in order h1>h2>h3.
- Links: <a href>; external: target="_blank" rel="noopener". Images: <img src alt width height loading="lazy">. Always write alt text.
- Forms: <label for=id> + <input id name type required>; types: text email tel number date password search checkbox radio; <button type="submit">.
- Lists: ul/ol>li. Tables: table>thead/tbody>tr>th/td. Media: <video controls>, <audio controls>.
- SEO: unique <title> (<60 chars), meta description (<160), Open Graph tags (og:title, og:image), favicon <link rel="icon">.
- Accessibility: use real <button> for actions, aria-label on icon-only buttons, contrast >= 4.5:1, visible focus outline.
- Multi-file site: index.html + style.css + script.js linked via <link rel="stylesheet" href="style.css"> and <script src="script.js" defer>.

import sys
from datax import config
if sys.stdout is None or sys.stderr is None:  # تشغيل بدون نافذة سوداء: السجل في ملف
    _f = open(config.HOME / "datax.log", "a", encoding="utf-8", buffering=1); sys.stdout = sys.stdout or _f; sys.stderr = sys.stderr or _f
from datax.server import main
if __name__ == "__main__": main()

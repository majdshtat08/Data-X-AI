# DATA X

مساعد ذكاء اصطناعي شخصي مجاني يعمل على جهازك: برمجة، مواقع، تصميم، ومونتاج ريلز. صُنع بواسطة **مجد الدين شتات — رئيس Data X Team**.
A free personal AI assistant that runs on your PC: coding, websites, design and reels. Created by **Majd Al-Din Shattat — President of Data X Team**.

## ⬇ التحميل / Download
أحدث إصدار / Latest release: [**Releases → DATAX.exe**](../../releases/latest)

شغّل الملف، أول مرة بيجهّز نفسه تلقائياً (Ollama + نموذج مناسب لجهازك). / Run it; on first launch it sets itself up (Ollama + a model that fits your PC).

## للمطوّرين / For developers
- تشغيل من الكود: `START_DATAX.bat` (ويندوز) أو `python run.py`
- الاختبارات: `python tests/test_extra.py && python tests/test_all.py`
- إضافات: ضع ملف `.py` في `plugins/` · معرفة إضافية: ملفات `.md` في `knowledge/`
- الموقع: مجلد `docs/` (HTML + CSS + JS) ← GitHub Pages
- بناء exe تلقائياً: `.github/workflows/build.yml`

import json, threading, urllib.error, uuid
from . import config, db, knowledge, llm, tools

SYSTEM = """أنت DATA X، مساعد شخصي على ويندوز. ردّ بلغة المستخدم وباختصار.
نفّذ بالأدوات مباشرة، وتحقق من النتيجة، ولا تدّعِ نجاحاً لم يحدث.
مواقع: استخدم make_website أولاً (ينشئ index.html وstyle.css وscript.js جاهزة) ثم عدّلها إن لزم ثم open_target. غلاف: make_cover. صورة: ai_image بوصف إنجليزي. ريلز: make_reel.
لا تكشف كلمات المرور. الحذف والأوامر الخطيرة تحتاج موافقة المستخدم. مجلد العمل: {ws}"""
PREV = {}

class Task:
    def __init__(self, chat, text):
        self.chat, self.text, self.events, self.pending = chat, text, [], {}
        self.cv, self.done, self.cancel = threading.Condition(), False, False
        threading.Thread(target=self._run, daemon=True).start()

    def emit(self, type, **kw):
        with self.cv: self.events.append({"i": len(self.events), "type": type, **kw}); self.cv.notify_all()

    def approve(self, cid, ok):
        ev = self.pending.get(cid)
        if ev: ev["ok"] = ok; ev["e"].set()

    def _ask(self, cid, name, args):
        ev = self.pending[cid] = {"e": threading.Event(), "ok": False}
        self.emit("approval", id=cid, name=name, input=args)
        ev["e"].wait(300); self.pending.pop(cid, None); return ev["ok"]

    def _run(self):
        try: self._loop()
        except urllib.error.URLError: self.emit("error", text="Ollama غير شغال. افتح برنامج Ollama (أو شغّل START_DATAX.bat) ثم أعد المحاولة.")
        except Exception as e: self.emit("error", text=f"{type(e).__name__}: {e}")
        finally:
            with self.cv: self.done = True; self.cv.notify_all()

    def _exec(self, name, args):
        cid = uuid.uuid4().hex[:8]; self.emit("tool", name=name, input=args)
        if name in tools.REG and tools.needs_approval(name, args, config.load()["auto_approve"]) and not self._ask(cid, name, args):
            self.emit("result", name=name, text="رُفضت العملية", files=[]); return "رفض المستخدم تنفيذ هذه العملية."
        tools.begin(); out = str(tools.run(name, args)); files = tools.end()
        self.emit("result", name=name, text=out[:400], files=files); return out

    def _loop(self):
        s = config.load()
        if llm.models() is None: raise urllib.error.URLError("down")
        model = llm.pick(s)
        if not model: raise RuntimeError("لا يوجد نموذج منزّل. نفّذ: ollama pull " + llm.recommended())
        msgs = [{"role": m["role"], **m["content"]} if isinstance(m["content"], dict) else {"role": m["role"], "content": m["content"]}
                for m in db.load(self.chat)[-10:] if isinstance(m["content"], (str, dict))]
        while msgs and msgs[0]["role"] != "user": msgs.pop(0)
        msgs.append({"role": "user", "content": self.text}); db.add(self.chat, "user", self.text)
        names = tools.select(self.text, PREV.get(self.chat)); PREV[self.chat] = names
        schemas = [tools.REG[n]["schema"] for n in names]; use_tools = bool(schemas)
        k = knowledge.lookup(self.text); sysmsg = SYSTEM.format(ws=config.WORKSPACE) + (("\n\n# مراجع\n" + k) if k else "")
        for _ in range(s["max_steps"]):
            if self.cancel: return self.emit("error", text="تم الإيقاف")
            text, calls = "", []
            try:
                for d in llm.stream(model, msgs, schemas if use_tools else None, sysmsg, s["ctx"]):
                    m = d.get("message", {})
                    if m.get("content"): text += m["content"]; self.emit("token", text=m["content"])
                    calls += m.get("tool_calls") or []
                    if d.get("eval_count") and d.get("eval_duration"): self.emit("stats", text=f"{d['eval_count'] / d['eval_duration'] * 1e9:.1f} tok/s · {model}")
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "replace")
                if e.code == 404: raise RuntimeError(f"النموذج {model} غير منزّل. نفّذ: ollama pull {model}")
                if use_tools and "tool" in body.lower(): use_tools = False; self.emit("notice", text="هذا النموذج لا يدعم الأدوات، سأجيب بالنص فقط."); continue
                raise RuntimeError(f"Ollama {e.code}: {body[:300]}")
            if use_tools and not calls:
                calls, clean = llm.text_calls(text, tools.REG)
                if calls: text = clean; self.emit("replace", text=clean)
            a = {"content": text}
            if calls: a["tool_calls"] = calls
            msgs.append({"role": "assistant", **a}); db.add(self.chat, "assistant", a); self.emit("msg_end")
            if not calls: return self.emit("final")
            for c in calls:
                f = c["function"]; args = f.get("arguments") or {}
                if isinstance(args, str):
                    try: args = json.loads(args)
                    except Exception: args = {}
                out = self._exec(f["name"], args if isinstance(args, dict) else {})[:2000]
                msgs.append({"role": "tool", "tool_name": f["name"], "content": out}); db.add(self.chat, "tool", {"tool_name": f["name"], "content": out})
        self.emit("error", text="وصلت للحد الأقصى من الخطوات. اكتب «أكمل» للمتابعة.")

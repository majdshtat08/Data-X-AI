keywords: javascript|\bjs\b|جافا ?سكربت|dom|fetch|async|event|react|node|json|api|script|تفاعل
# JavaScript essentials
- Select: document.querySelector('.x'), querySelectorAll; events: el.addEventListener('click', e => {...}); toggle classes: el.classList.toggle('open').
- Create/modify: el.textContent = 'safe text' (avoid innerHTML with user input -> XSS); el.setAttribute; parent.append(child).
- Variables: const/let (never var). Arrow fns, template strings `Hi ${name}`, destructuring const {a,b}=obj, spread [...arr], optional chaining obj?.x ?? 'default'.
- Arrays: map, filter, find, reduce, some, every, sort((a,b)=>a-b). Objects: Object.entries/keys, JSON.stringify/parse.
- Async: async function load(){ try{ const r = await fetch(url); if(!r.ok) throw new Error(r.status); return await r.json(); }catch(e){ console.error(e) } }
- Storage: localStorage.setItem('k', JSON.stringify(v)); JSON.parse(localStorage.getItem('k')||'null').
- Observers: IntersectionObserver for scroll-reveal; setTimeout/setInterval; requestAnimationFrame for animation.
- Modules: <script type="module">, export/import. Always handle errors; debug with console.log and the browser DevTools (F12).
- Node.js: npm init -y; npm i express; require/import; fs, path modules. React: components are functions returning JSX, state via useState, effects via useEffect.

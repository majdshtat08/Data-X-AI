keywords: \bgit\b|github|pages|نشر|publish|deploy|repo|commit|netlify|vercel|رفع
# Git & GitHub Pages
- Local: git init; git add .; git commit -m "msg"; git branch -M main; git remote add origin https://github.com/USER/REPO.git; git push -u origin main. Status: git status, git log --oneline.
- Never commit secrets (passwords, API keys). Use .gitignore for node_modules, __pycache__, .env.
- GitHub Pages (free static hosting): repo Settings -> Pages -> Source: "Deploy from a branch" -> branch main, folder / (root) or /docs -> Save. Site URL: https://USER.github.io/REPO/ (ready in ~1 minute). index.html must be at the chosen folder root; add an empty .nojekyll file.
- Releases: GitHub Releases host downloadable files (installers); stable link: https://github.com/USER/REPO/releases/latest/download/FILE.exe. GitHub Actions (.github/workflows/*.yml) can build apps automatically.
- Custom domain: Settings -> Pages -> Custom domain (add CNAME DNS record). Alternatives: Netlify drop, Vercel, Cloudflare Pages.

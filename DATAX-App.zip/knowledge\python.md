keywords: python|بايثون|\bpip\b|سكربت|flask|django|pandas|requests|مكتبة
# Python essentials
- Basics: print(), f"{x}", lists [], dicts {}, sets, tuples; loops: for i in range(n), for k,v in d.items(); comprehensions [x*2 for x in xs if x>0].
- Functions: def f(a, b=1, *args, **kw): return a; classes: class A: def __init__(self): ...; dataclasses for records.
- Files: with open(p, encoding='utf-8') as f: text=f.read(); pathlib.Path(p).read_text('utf-8'); json.load/dump; csv module.
- Errors: try/except ValueError as e; raise; read the Traceback from the bottom up (last line = the error).
- HTTP: urllib.request (stdlib) or requests (pip install requests). Web: Flask -> app=Flask(__name__); @app.route('/') def home(): return 'hi'; app.run().
- Env: python -m venv venv; pip install pkg; pip freeze > requirements.txt. Scripts run with python file.py.
- Data: pandas (read_csv, df.groupby, df.describe); plotting: matplotlib. Automation: os, shutil, subprocess, schedule.
- Style: PEP8, snake_case names, small functions, docstrings, type hints def f(x: int) -> str.

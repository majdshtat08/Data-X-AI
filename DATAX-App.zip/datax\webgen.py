"""مولّد مواقع: index.html + style.css + script.js بتصميم عصري يدعم العربية/الإنجليزية، جاهز لـ GitHub Pages."""
import html as H, pathlib
THEMES = {"blue": ("#3b82f6", "#8b5cf6", "#0b1020"), "green": ("#10b981", "#06b6d4", "#07130f"), "orange": ("#f59e0b", "#ef4444", "#150d07"), "pink": ("#ec4899", "#8b5cf6", "#14081a")}
L = {"ar": ("من نحن", "المميزات", "تواصل معنا", "ابدأ الآن", "جميع الحقوق محفوظة"), "en": ("About", "Features", "Contact", "Get started", "All rights reserved")}
DEFAULT_FEATURES = {"ar": ["سريع|أداء عالٍ وموثوق", "عصري|تصميم حديث وأنيق", "متجاوب|يعمل على كل الشاشات"], "en": ["Fast|Quick and reliable", "Modern|Clean modern design", "Responsive|Works on every screen"]}
HTML = """<!DOCTYPE html>
<html lang="__LANG__" dir="__DIR__">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>__NAME__</title><meta name="description" content="__TAG__">
<link rel="stylesheet" href="style.css">
</head>
<body>
<header class="nav"><a class="brand" href="#top">__NAME__</a>
<button class="burger" aria-label="menu" id="burger">☰</button>
<nav id="menu"><a href="#about">__N0__</a><a href="#features">__N1__</a><a href="#contact">__N2__</a></nav></header>
<main id="top">
<section class="hero"><div class="glow"></div><h1 class="reveal">__NAME__</h1><p class="reveal">__TAG__</p><a class="btn reveal" href="#features">__N3__</a></section>
<section id="about" class="wrap reveal"><h2>__N0__</h2><p>__ABOUT__</p></section>
<section id="features" class="wrap"><h2>__N1__</h2><div class="grid">__CARDS__</div></section>
<section id="contact" class="wrap reveal"><h2>__N2__</h2><p>__CONTACT__</p></section>
</main>
<footer>© <span id="year"></span> __NAME__ — __N4__</footer>
<script src="script.js"></script>
</body></html>
"""
CSS = """:root{--c1:__C1__;--c2:__C2__;--bg:__BG__;--card:#ffffff0d;--tx:#eef0ff;--mu:#a3a8cf}
*{box-sizing:border-box;margin:0}html{scroll-behavior:smooth}
body{background:var(--bg);color:var(--tx);font:17px/1.8 "Segoe UI",Tahoma,Arial,sans-serif}
.nav{position:sticky;top:0;z-index:10;display:flex;align-items:center;justify-content:space-between;padding:14px 6%;background:#0009;backdrop-filter:blur(12px);border-bottom:1px solid #ffffff14}
.brand{font-weight:800;font-size:22px;color:var(--tx);text-decoration:none;background:linear-gradient(135deg,var(--c1),var(--c2));-webkit-background-clip:text;background-clip:text;color:transparent}
nav a{color:var(--mu);text-decoration:none;margin-inline-start:22px}nav a:hover{color:var(--tx)}.burger{display:none;background:none;border:0;color:var(--tx);font-size:26px;cursor:pointer}
.hero{position:relative;overflow:hidden;text-align:center;padding:120px 6% 110px}.glow{position:absolute;inset:-30% 10% auto;height:420px;background:radial-gradient(circle,var(--c2)55,transparent 65%);filter:blur(40px);z-index:-1}
.hero h1{font-size:clamp(38px,7vw,72px);line-height:1.2;background:linear-gradient(135deg,var(--c1),var(--c2));-webkit-background-clip:text;background-clip:text;color:transparent}
.hero p{max-width:640px;margin:18px auto 32px;color:var(--mu);font-size:20px}
.btn{display:inline-block;padding:14px 34px;border-radius:14px;color:#fff;text-decoration:none;font-weight:700;background:linear-gradient(135deg,var(--c1),var(--c2));box-shadow:0 10px 30px #0006;transition:transform .2s}.btn:hover{transform:translateY(-3px)}
.wrap{max-width:1050px;margin:0 auto;padding:70px 6%}h2{font-size:34px;margin-bottom:18px}.wrap>p{color:var(--mu);max-width:760px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:26px}
.card{background:var(--card);border:1px solid #ffffff1a;border-radius:18px;padding:26px;transition:transform .25s,border-color .25s}.card:hover{transform:translateY(-6px);border-color:var(--c2)}.card h3{margin-bottom:8px}.card p{color:var(--mu);font-size:15px}
footer{text-align:center;color:var(--mu);padding:36px;border-top:1px solid #ffffff14;font-size:14px}
.reveal{opacity:0;transform:translateY(24px);transition:opacity .7s,transform .7s}.reveal.show{opacity:1;transform:none}
@media(max-width:720px){.burger{display:block}nav{display:none;position:absolute;top:100%;inset-inline:0;background:#000d;flex-direction:column;padding:12px 6%}nav.open{display:flex}nav a{margin:10px 0}}
"""
JS = """const menu = document.getElementById("menu");
document.getElementById("burger").addEventListener("click", () => menu.classList.toggle("open"));
menu.querySelectorAll("a").forEach(a => a.addEventListener("click", () => menu.classList.remove("open")));
document.getElementById("year").textContent = new Date().getFullYear();
const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && e.target.classList.add("show")), { threshold: 0.15 });
document.querySelectorAll(".reveal").forEach(el => io.observe(el));
"""
def build(folder, name, tagline, about, features, theme="blue", lang="ar", contact=""):
    c1, c2, bg = THEMES.get(theme, THEMES["blue"]); n = L.get(lang, L["ar"]); e = H.escape; cards = ""
    for f in features or DEFAULT_FEATURES.get(lang, DEFAULT_FEATURES["ar"]):
        t, _, d = str(f).partition("|"); cards += f'<article class="card reveal"><h3>{e(t.strip())}</h3><p>{e(d.strip())}</p></article>'
    page = HTML.replace("__LANG__", lang if lang in L else "ar").replace("__DIR__", "ltr" if lang == "en" else "rtl").replace("__NAME__", e(name)).replace("__TAG__", e(tagline or name))
    page = page.replace("__ABOUT__", e(about or tagline or name)).replace("__CARDS__", cards).replace("__CONTACT__", e(contact or "")).replace("__N0__", n[0]).replace("__N1__", n[1]).replace("__N2__", n[2]).replace("__N3__", n[3]).replace("__N4__", n[4])
    folder = pathlib.Path(folder); folder.mkdir(parents=True, exist_ok=True)
    out = {"index.html": page, "style.css": CSS.replace("__C1__", c1).replace("__C2__", c2).replace("__BG__", bg), "script.js": JS}
    for k, v in out.items(): (folder / k).write_text(v, "utf-8")
    return [folder / k for k in out]

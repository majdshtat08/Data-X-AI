import json, sqlite3, threading, time
from .config import HOME
_c = sqlite3.connect(HOME / "history.db", check_same_thread=False); _l = threading.Lock()
_c.execute("create table if not exists msgs(id integer primary key, chat text, role text, content text, ts real)")
def add(chat, role, content):
    with _l: _c.execute("insert into msgs(chat,role,content,ts) values(?,?,?,?)", (chat, role, json.dumps(content, ensure_ascii=False), time.time())); _c.commit()
def load(chat):
    with _l: rows = _c.execute("select role,content from msgs where chat=? order by id", (chat,)).fetchall()
    return [{"role": r, "content": json.loads(c)} for r, c in rows]
def chats():
    q = "select chat,(select content from msgs b where b.chat=m.chat and b.role='user' order by id limit 1) from msgs m group by chat order by max(ts) desc limit 50"
    out = []
    with _l: rows = _c.execute(q).fetchall()
    for c, t in rows:
        try: t = json.loads(t)
        except Exception: t = ""
        out.append({"id": c, "title": (t if isinstance(t, str) else "")[:40] or c})
    return out
def delete(chat):
    with _l: _c.execute("delete from msgs where chat=?", (chat,)); _c.commit()

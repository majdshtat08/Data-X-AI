import json, mimetypes, os, pathlib, subprocess, threading, time, urllib.parse, uuid, webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from . import config, db, llm, tools
from .agent import Task
WEB = config.RES / "web"; TASKS = {}; SEEN = [0.0]
def _txt(c): return c if isinstance(c, str) else (c.get("content") or "" if isinstance(c, dict) else "")

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=()):
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        for k, v in extra: self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)
    def _j(self, obj, code=200): self._send(code, json.dumps(obj, ensure_ascii=False).encode())
    def _ok(self):  # حماية: المضيف المحلي فقط (ضد DNS rebinding) وأصل الطلب نفسه
        if self.headers.get("Host", "").split(":")[0] not in ("127.0.0.1", "localhost"): return False
        o = self.headers.get("Origin"); return o is None or o.startswith(("http://127.0.0.1", "http://localhost"))

    def do_GET(self):
        if not self._ok(): return self._j({"error": "forbidden"}, 403)
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}; p = u.path
        if p == "/": self._send(200, (WEB / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif p == "/api/health":
            SEEN[0] = time.time(); ms = llm.models(); self._j({"ollama": ms is not None, "model": llm.pick() if ms is not None else None, "models": ms or [], "msg": llm.STATE["msg"]})
        elif p == "/api/chats": self._j(db.chats())
        elif p == "/api/history": self._j([{"role": m["role"], "content": x} for m in db.load(q.get("chat", "")) if m["role"] != "tool" and (x := _txt(m["content"]))])
        elif p == "/api/settings": self._j(config.load())
        elif p == "/api/stream": self._stream(TASKS.get(q.get("task")))
        elif p.startswith("/files/"):
            f = (config.WORKSPACE / urllib.parse.unquote(p[7:])).resolve()
            try: f.relative_to(config.WORKSPACE.resolve())
            except ValueError: return self._j({"error": "forbidden"}, 403)
            if not f.is_file(): return self._j({"error": "not found"}, 404)
            self._send(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream", [("Content-Security-Policy", "sandbox allow-scripts allow-popups")])
        else: self._j({"error": "not found"}, 404)

    def _stream(self, t):
        if not t: return self._j({"error": "no task"}, 404)
        self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Cache-Control", "no-cache"); self.end_headers(); i = 0
        try:
            while True:
                with t.cv:
                    if i >= len(t.events) and not t.done: t.cv.wait(10)
                    batch, done = t.events[i:], t.done
                for e in batch: self.wfile.write(f"id: {e['i']}\ndata: {json.dumps(e, ensure_ascii=False)}\n\n".encode())
                i += len(batch)
                if not batch and not done: self.wfile.write(b": ping\n\n")
                if done and i >= len(t.events): self.wfile.write(b"event: end\ndata: {}\n\n"); self.wfile.flush(); return
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError): pass

    def do_POST(self):
        if not self._ok(): return self._j({"error": "forbidden"}, 403)
        try: b = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0)) or 2) or b"{}")
        except Exception: return self._j({"error": "bad json"}, 400)
        if self.path == "/api/chat":
            text = str(b.get("text", "")).strip()
            if not text: return self._j({"error": "empty"}, 400)
            chat, tid = b.get("chat") or uuid.uuid4().hex[:8], uuid.uuid4().hex[:8]; TASKS[tid] = Task(chat, text); self._j({"task": tid, "chat": chat})
        elif self.path == "/api/approve":
            t = TASKS.get(b.get("task")); t and t.approve(b.get("id"), bool(b.get("ok"))); self._j({"ok": True})
        elif self.path == "/api/cancel":
            t = TASKS.get(b.get("task")); t and setattr(t, "cancel", True); self._j({"ok": True})
        elif self.path == "/api/delete_chat": db.delete(b.get("chat", "")); self._j({"ok": True})
        elif self.path == "/api/open_folder":
            os.startfile(str(config.WORKSPACE)) if os.name == "nt" else None; self._j({"ok": True, "path": str(config.WORKSPACE)})
        elif self.path == "/api/settings":
            s = config.load(); s.update({k: v for k, v in b.items() if k in ("model", "auto_approve", "lang")}); config.save(s); self._j(s)
        else: self._j({"error": "not found"}, 404)

def open_window(url):
    """يفتح DATA X كنافذة تطبيق مستقلة (Edge/Chrome بوضع --app) بدل تبويب عادي."""
    b = tools.browser()
    if b:
        try: subprocess.Popen([b, f"--app={url}", "--window-size=1280,820", f"--user-data-dir={config.HOME / 'appprofile'}", "--no-first-run", "--no-default-browser-check"]); return
        except Exception: pass
    webbrowser.open(url)

def main(port=8765, open_browser=True):
    tools.load_plugins(); url = f"http://127.0.0.1:{port}"
    try: srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    except OSError:
        print("DATA X يعمل بالفعل"); open_browser and open_window(url); return
    srv.daemon_threads = True; threading.Thread(target=llm.background_setup, daemon=True).start()
    def watch():  # يُغلق نفسه بعد إغلاق النافذة بدقيقتين (لا يبقى يستهلك الجهاز)
        while True:
            time.sleep(15)
            if SEEN[0] and time.time() - SEEN[0] > 120 and all(t.done for t in TASKS.values()): os._exit(0)
    threading.Thread(target=watch, daemon=True).start()
    print(f"DATA X يعمل على {url}")
    if open_browser: open_window(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

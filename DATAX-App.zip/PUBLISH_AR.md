# خطوات النشر على GitHub (مرة وحدة)

1. أنشئ حساب مجاني على github.com ثم اضغط **New repository**. الاسم: `datax`، النوع: **Public**، ثم **Create repository**.
2. اضغط **uploading an existing file**. افتح مجلد المشروع بعد فك الضغط، حدّد **كل** الملفات والمجلدات داخله (Ctrl+A) واسحبها للصفحة، ثم **Commit changes**.
   - تأكد إن مجلد `.github` انرفع. إذا لا: **Add file → Create new file**، اكتب الاسم `.github/workflows/build.yml` والصق محتوى الملف الموجود عندك بنفس المسار.
3. **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*، Branch = `main`، Folder = `/docs`، ثم **Save**. بعد دقيقة موقعك يكون على: `https://اسمك.github.io/datax/`
4. تبويب **Actions → Build DATA X → Run workflow**. انتظر 5 إلى 10 دقائق. بعدها بتلاقي **Release** فيه `DATAX.exe`.
5. افتح موقعك: زر التحميل بيربط نفسه بآخر إصدار تلقائياً. شارك رابط الموقع.

لإصدار نسخة جديدة: عدّل الملفات ثم Actions → Run workflow من جديد.

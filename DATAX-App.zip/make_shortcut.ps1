$root = $PSScriptRoot
$py = Get-Command pythonw -ErrorAction SilentlyContinue
if (-not $py) { $py = Get-Command python }
$w = New-Object -ComObject WScript.Shell
foreach ($d in @([Environment]::GetFolderPath('Desktop'), "$env:APPDATA\Microsoft\Windows\Start Menu\Programs")) {
  $s = $w.CreateShortcut("$d\DATA X.lnk")
  $s.TargetPath = $py.Source; $s.Arguments = "run.py"; $s.WorkingDirectory = $root
  $s.IconLocation = "$root\datax.ico"; $s.Description = "DATA X"; $s.Save()
}

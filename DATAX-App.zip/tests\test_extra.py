import os, sys, tempfile
os.environ["APPDATA"] = tempfile.mkdtemp(); sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datax import tools; tools.load_plugins()
s = tools.select
assert s("مرحبا كيفك اليوم") == [] and s("hello how are you") == []                 # دردشة عادية: بدون أدوات = سريع
assert {"write_file", "open_target"} <= set(s("اعمل لي موقع احترافي")) and "make_reel" not in s("اعمل لي موقع")
assert {"make_cover", "make_reel"} <= set(s("صمم غلاف وجهز ريل")) and "word_count" in s("اعمل ريل")  # الإضافات تُضاف
assert s("أكمل", ["write_file"]) == ["write_file"]                                  # المتابعة تحتفظ بأدوات الطلب السابق
print("اختبار التوجيه نجح ✅")

# --- المعرفة ومولّد المواقع ---
import html.parser, pathlib
from datax import knowledge, tools as T, config
assert knowledge.lookup("hello") == "" and knowledge.lookup("مرحبا") == ""
assert "grid" in knowledge.lookup("make css grid layout").lower() and "make_website" in knowledge.lookup("اعمل لي موقع")
assert "github" in knowledge.lookup("كيف انشر على github pages").lower() and len(knowledge.lookup("موقع css javascript python")) <= 2200
r = T.run("make_website", {"name": "Data X Team", "tagline": "برمجة وتصميم", "about": "فريق", "features": "سريع|وصف\nعصري|وصف2", "folder": "tsite", "theme": "violet", "lang": "ar"})
d = config.WORKSPACE / "tsite"; assert "تم" in r and all((d / f).exists() for f in ("index.html", "style.css", "script.js")), r
page = (d / "index.html").read_text("utf-8"); assert 'dir="rtl"' in page and page.count('class="card') == 2 and "<script" in page
class Chk(html.parser.HTMLParser):
    def __init__(s): super().__init__(); s.st = []
    def handle_starttag(s, t, a):
        if t not in ("meta", "link", "br", "img", "input"): s.st.append(t)
    def handle_endtag(s, t): assert s.st and s.st.pop() == t, t
c = Chk(); c.feed(page); assert not c.st, c.st                                  # HTML متوازن
assert "__" not in page and "__" not in (d / "style.css").read_text("utf-8")    # لا بقايا قوالب
assert 'dir="ltr"' in (T.run("make_website", {"name": "A", "folder": "e", "lang": "en"}) and (config.WORKSPACE / "e/index.html").read_text("utf-8"))
print("اختبار المعرفة والمواقع نجح ✅")

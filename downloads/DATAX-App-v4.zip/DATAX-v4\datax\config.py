import json, os, pathlib, shutil, sys
HOME = pathlib.Path(os.environ.get("APPDATA", pathlib.Path.home())) / "DataX"
HOME.mkdir(parents=True, exist_ok=True)
WORKSPACE = HOME / "workspace"; WORKSPACE.mkdir(exist_ok=True)
_F = HOME / "settings.json"
DEFAULTS = {"v": 3, "model": "auto", "ollama_url": "http://127.0.0.1:11434", "lang": "ar",
            "max_steps": 20, "ctx": 4096, "auto_approve": False}
def load():
    s = dict(DEFAULTS)
    try:
        d = json.loads(_F.read_text("utf-8"))
        if d.get("v") in (2, 3): s.update({k: v for k, v in d.items() if k in DEFAULTS})
    except Exception: pass
    return s
def save(s): _F.write_text(json.dumps({k: s[k] for k in DEFAULTS if k in s}, ensure_ascii=False, indent=2), "utf-8")

RES = pathlib.Path(getattr(sys, "_MEIPASS", pathlib.Path(__file__).resolve().parent.parent))  # يعمل من الكود ومن ملف exe
NOWIN = 0x08000000 if os.name == "nt" else 0  # بدون نوافذ سوداء
def find_exe(name):
    w = shutil.which(name)
    if w or os.name != "nt": return w
    la = os.environ.get("LOCALAPPDATA", "")
    candidates = {
        "ollama": [
            la + r"\Programs\Ollama\ollama.exe",
            r"C:\Program Files\Ollama\ollama.exe",
            r"C:\Program Files (x86)\Ollama\ollama.exe",
        ],
        "ffmpeg": [
            la + r"\Microsoft\WinGet\Links\ffmpeg.exe",
            r"C:\ffmpeg\bin\ffmpeg.exe",
        ],
        "kdenlive": [
            la + r"\Microsoft\WinGet\Links\kdenlive.exe",
            r"C:\Program Files\Kdenlive\bin\kdenlive.exe",
            r"C:\Program Files (x86)\Kdenlive\bin\kdenlive.exe",
        ],
    }
    for c in candidates.get(name, []):
        if os.path.exists(c): return c
    if name == "ffmpeg":
        packages = pathlib.Path(la) / "Microsoft" / "WinGet" / "Packages"
        for candidate in packages.rglob("ffmpeg.exe"):
            return str(candidate)
    if name == "kdenlive":
        packages = pathlib.Path(la) / "Microsoft" / "WinGet" / "Packages"
        for candidate in packages.rglob("kdenlive.exe"):
            return str(candidate)

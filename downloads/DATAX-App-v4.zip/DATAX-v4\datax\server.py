import datetime, io, json, mimetypes, os, pathlib, subprocess, tempfile, threading, time, urllib.parse, uuid, webbrowser, zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from . import attachments, config, db, llm, tools
from .agent import Task
WEB = config.RES / "web"; TASKS = {}; SEEN = [0.0]; CHAT_TITLES = {}
MAX_BODY_SIZE = 58 * 1024 * 1024
def _txt(c): return c if isinstance(c, str) else (c.get("content") or "" if isinstance(c, dict) else "")

def export_workspace(output):
    workspace = config.WORKSPACE.resolve()
    count = 0
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in sorted(workspace.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            rel = path.resolve().relative_to(workspace)
            if rel.parts and rel.parts[0] == ".tmp":
                continue
            archive.write(path, "DataX-Files/" + rel.as_posix())
            count += 1
    return count

def export_name():
    stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"DATAX_Files_{stamp}.zip"

class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=()):
        self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(body)))
        for k, v in extra: self.send_header(k, v)
        self.end_headers(); self.wfile.write(body)
    def _j(self, obj, code=200): self._send(code, json.dumps(obj, ensure_ascii=False).encode())
    def _ok(self):
        host = urllib.parse.urlsplit("//" + self.headers.get("Host", "")).hostname
        if host not in ("127.0.0.1", "localhost", "::1"):
            return False
        o = self.headers.get("Origin")
        if o is None:
            return True
        parsed = urllib.parse.urlsplit(o)
        return parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost", "::1")

    def _body(self):
        try: size = int(self.headers.get("Content-Length", "0"))
        except ValueError: self._j({"error": "bad content length"}, 400); return None
        if size < 0 or size > MAX_BODY_SIZE:
            self._j({"error": "حجم الطلب أكبر من الحد المسموح"}, 413); return None
        try: value = json.loads(self.rfile.read(size) or b"{}")
        except (json.JSONDecodeError, UnicodeDecodeError): self._j({"error": "bad json"}, 400); return None
        if not isinstance(value, dict): self._j({"error": "invalid request"}, 400); return None
        return value

    def do_GET(self):
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}; p = u.path
        if p == "/api/export_zip":
            if not self._ok():
                return self._j({"error": "forbidden"}, 403)
            with tempfile.TemporaryDirectory() as folder:
                archive_path = pathlib.Path(folder) / export_name()
                count = export_workspace(archive_path)
                body = archive_path.read_bytes()
            name = archive_path.name
            return self._send(200, body, "application/zip", [
                ("Content-Disposition", f'attachment; filename="{name}"'),
                ("X-Download-File-Count", str(count)),
                ("Cache-Control", "no-store"),
            ])
        if p.startswith("/preview/"):
            rel = urllib.parse.unquote(p[len("/preview/"):]).replace("\\", "/")
            if ".." in pathlib.PurePosixPath(rel).parts:
                return self._j({"error": "not found"}, 404)
            f = (config.WORKSPACE / rel).resolve()
            if not f.is_file():
                return self._j({"error": "not found"}, 404)
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            return self._send(200, f.read_bytes(), ctype, [
                ("Content-Security-Policy", "sandbox allow-scripts allow-popups allow-modals"),
                ("X-Content-Type-Options", "nosniff"),
            ])
        if p.startswith("/files/"):
            rel = urllib.parse.unquote(p[len("/files/"):]).replace("\\", "/")
            if ".." in pathlib.PurePosixPath(rel).parts:
                return self._j({"error": "not found"}, 404)
            f = (config.WORKSPACE / rel).resolve()
            workspace = config.WORKSPACE.resolve()
            if os.path.commonpath([str(f), str(workspace)]) != str(workspace):
                return self._j({"error": "not found"}, 404)
            if not f.is_file():
                return self._j({"error": "not found"}, 404)
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            return self._send(200, f.read_bytes(), ctype, [
                ("Content-Security-Policy", "sandbox allow-scripts allow-popups allow-modals"),
                ("X-Content-Type-Options", "nosniff"),
            ])
        u = urllib.parse.urlparse(self.path); q = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}; p = u.path
        if p == "/favicon.ico":
            return self._send(204, b"", "image/x-icon")
        if p == "/": self._send(200, (WEB / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif p.startswith("/preview/"):
            rel = urllib.parse.unquote(p[len("/preview/"):]).replace("\\", "/")
            if ".." in pathlib.PurePosixPath(rel).parts:
                return self._j({"error": "not found"}, 404)
            f = (config.WORKSPACE / rel).resolve()
            workspace = config.WORKSPACE.resolve()
            if os.path.commonpath([str(f), str(workspace)]) != str(workspace):
                return self._j({"error": "not found"}, 404)
            if not f.is_file():
                return self._j({"error": "not found"}, 404)
            ctype = mimetypes.guess_type(f.name)[0] or "application/octet-stream"
            self._send(200, f.read_bytes(), ctype, [
                ("Content-Security-Policy", "sandbox allow-scripts allow-popups allow-modals"),
                ("X-Content-Type-Options", "nosniff"),
            ])
        elif p == "/api/health":
            SEEN[0] = time.time(); ms = llm.models(); ffmpeg = bool(config.find_exe("ffmpeg"))
            kdenlive = bool(config.find_exe("kdenlive"))
            self._j({"ollama": ms is not None, "model": llm.pick() if ms is not None else None, "models": ms or [],
                      "vision": llm.vision_model() if ms is not None else None, "ffmpeg": ffmpeg,
                      "kdenlive": kdenlive, "general_model": llm.general_model(),
                      "coder_model": llm.coder_model(), "math_model": llm.math_model(), "msg": llm.STATE.get("msg", "")})
        elif p == "/api/chats":
            chats = db.chats()
            for chat in chats:
                if chat["id"] in CHAT_TITLES:
                    chat["title"] = CHAT_TITLES[chat["id"]]
            self._j(chats)
        elif p == "/api/history":
            self._j([{"role": m["role"], "content": _txt(m["content"]),
                      "attachments": m["content"].get("attachments", []) if isinstance(m["content"], dict) else []}
                     for m in db.load(q.get("chat", "")) if m["role"] != "tool" and (_txt(m["content"]) or (isinstance(m["content"], dict) and m["content"].get("attachments")))])
        elif p == "/api/settings": self._j(config.load())
        elif p == "/api/memory": self._j(db.memories(q.get("chat", ""), 100))
        elif p == "/api/stream": self._stream(TASKS.get(q.get("task")))
        elif p.startswith("/files/"):
            f = (config.WORKSPACE / urllib.parse.unquote(p[7:])).resolve()
            try: f.relative_to(config.WORKSPACE.resolve())
            except ValueError: return self._j({"error": "forbidden"}, 403)
            if not f.is_file(): return self._j({"error": "not found"}, 404)
            self._send(200, f.read_bytes(), mimetypes.guess_type(f.name)[0] or "application/octet-stream", [("Content-Security-Policy", "sandbox allow-scripts allow-popups")])
        else: self._j({"error": "not found"}, 404)

    def _stream(self, t):
        if not t: return self._j({"error": "no task"}, 404)
        self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Cache-Control", "no-cache"); self.end_headers(); i = 0
        try:
            while True:
                with t.cv:
                    if i >= len(t.events) and not t.done: t.cv.wait(10)
                    batch, done = t.events[i:], t.done
                for e in batch: self.wfile.write(f"id: {e['i']}\ndata: {json.dumps(e, ensure_ascii=False)}\n\n".encode())
                i += len(batch)
                if not batch and not done: self.wfile.write(b": ping\n\n")
                if done and i >= len(t.events): self.wfile.write(b"event: end\ndata: {}\n\n"); self.wfile.flush(); return
                self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError, OSError): pass

    def do_POST(self):
        if not self._ok(): return self._j({"error": "forbidden"}, 403)
        b = self._body()
        if b is None: return
        if self.path == "/api/chat":
            text = b.get("text", "")
            files = b.get("files", [])
            if not isinstance(text, str) or len(text) > 100000: return self._j({"error": "النص المرسل غير صالح أو طويل جداً"}, 400)
            if not text.strip() and not files: return self._j({"error": "اكتب رسالة أو أرفق ملفاً"}, 400)
            try: uploaded = attachments.store_uploads(files)
            except ValueError as e: return self._j({"error": str(e)}, 400)
            chat, tid = b.get("chat") or uuid.uuid4().hex[:8], uuid.uuid4().hex[:8]
            title = text.strip().replace("\n", " ")[:40]
            if not title:
                title = "مرفقات: " + "، ".join(f["name"] for f in uploaded[:3])
            if title:
                CHAT_TITLES[chat] = " ".join(title.split())
            mode = b.get("mode", "auto")
            TASKS[tid] = Task(chat, text.strip(), uploaded, mode)
            self._j({"task": tid, "chat": chat, "attachments": uploaded})
        elif self.path == "/api/approve":
            t = TASKS.get(b.get("task")); t and t.approve(b.get("id"), bool(b.get("ok"))); self._j({"ok": True})
        elif self.path == "/api/cancel":
            t = TASKS.get(b.get("task")); t and setattr(t, "cancel", True); self._j({"ok": True})
        elif self.path == "/api/delete_chat": db.delete(b.get("chat", "")); self._j({"ok": True})
        elif self.path == "/api/open_folder":
            os.startfile(str(config.WORKSPACE)) if os.name == "nt" else None; self._j({"ok": True, "path": str(config.WORKSPACE)})
        elif self.path == "/api/settings":
            s = config.load(); s.update({k: v for k, v in b.items() if k in ("model", "auto_approve", "lang")}); config.save(s); self._j(s)
        elif self.path == "/api/pull_model":
            model = b.get("model", "")
            if model not in set(llm.GENERAL_MODELS + llm.CODER_MODELS + llm.VISION_MODELS + llm.MATH_MODELS):
                return self._j({"error": "النموذج غير مسموح من واجهة الإدارة"}, 400)
            try:
                threading.Thread(target=llm.ensure_model, args=(model,), daemon=True).start()
                self._j({"ok": True, "model": model})
            except Exception as e:
                self._j({"error": str(e)}, 500)
        elif self.path == "/api/remember":
            value = b.get("value", "")
            db.remember("user", value, b.get("chat", "")); self._j({"ok": True})
        elif self.path == "/api/forget":
            db.forget(b.get("chat", "") if b.get("chat") else ""); self._j({"ok": True})
        else: self._j({"error": "not found"}, 404)

def open_window(url):
    """يفتح DATA X كنافذة تطبيق مستقلة (Edge/Chrome بوضع --app) بدل تبويب عادي."""
    b = tools.browser()
    if b:
        try: subprocess.Popen([b, f"--app={url}", "--window-size=1280,820", f"--user-data-dir={config.HOME / 'appprofile'}", "--no-first-run", "--no-default-browser-check"]); return
        except Exception: pass
    webbrowser.open(url)

def main(port=8765, open_browser=True):
    tools.load_plugins(); url = f"http://127.0.0.1:{port}"
    try: srv = ThreadingHTTPServer(("127.0.0.1", port), H)
    except OSError:
        print("DATA X is already running"); open_browser and open_window(url); return
    srv.daemon_threads = True; threading.Thread(target=llm.background_setup, daemon=True).start()
    def watch():  # يُغلق نفسه بعد إغلاق النافذة بدقيقتين (لا يبقى يستهلك الجهاز)
        while True:
            time.sleep(15)
            if SEEN[0] and time.time() - SEEN[0] > 120 and all(t.done for t in TASKS.values()): os._exit(0)
    threading.Thread(target=watch, daemon=True).start()
    print("DATA X server: " + url)
    if open_browser: open_window(url)
    try: srv.serve_forever()
    except KeyboardInterrupt: pass

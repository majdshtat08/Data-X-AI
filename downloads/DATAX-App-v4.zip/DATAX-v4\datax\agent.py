import base64, json, pathlib, re, subprocess, tempfile, threading, urllib.error, uuid
from . import attachments, config, db, knowledge, llm, tools

SYSTEM = """أنت DATA X، مساعد شخصي ذكي على ويندوز. أجب دائماً بلغة آخر رسالة للمستخدم وبوضوح؛ إذا كتب بالعربية فأجب بالعربية ولا تنتقل للغة أخرى.
نفّذ بالأدوات مباشرة، وتحقق من النتيجة، ولا تدّعِ نجاحاً لم يحدث.
مواقع: نفّذ make_website ثم عدّلها إن لزم وافتحها بـ open_target. غلاف: نفّذ make_cover. توليد صورة: نفّذ ai_image بوصف إنجليزي واسم ملف مناسب. تعديل صورة: نفّذ edit_image على مسار المرفق الظاهر في الرسالة. ريلز/فيديو: استخدم make_reel للمرفقات بالترتيب، video_to_reel للفيديو الأفقي، video_trim للقص، وmake_cover للنصوص البصرية.
تحقق من المسارات قبل التنفيذ ولا تدّعِ إنشاء ملف لم يوجد فعلاً. لا تكشف كلمات المرور. الحذف والأوامر الخطيرة تحتاج موافقة. مجلد العمل: {ws}
المعلومات المحفوظة عن المستخدم: {memory}
يمكنك التعلم منه: احفظ التفضيلات والأسلوب والمعلومات التي يطلبها المستخدم بوضوح.
عند طلب برمجة أو موقع: نفذ الأدوات وأنشئ الملفات الكاملة. استخدم index.html وstyle.css وscript.js منفصلة عند إنشاء موقع. لا تختصر الكود بكلمات «باقي الكود» أو توضح أنه مثال جزئي. عند تعديل مشروع اقرأ الملف أولاً وعدله كاملاً. اجعل المشروع قابلاً للتشغيل محلياً وأذكر أسماء الملفات والمجلد."""
MATH_TUTOR = """أنت الآن مدرس مساعد للرياضيات المتقدمة لطلبة التوجيهي الأردني، الصف الثاني الثانوي.
حل المسألة بالعربية خطوة بخطوة: حدّد المطلوب والمعطيات، اذكر القانون أو الفكرة، عوّض بوضوح، نفّذ الحسابات، ثم تحقق من النتيجة واذكر الجواب النهائي.
اشرح التفاضل والتكامل والدوال بحسب السؤال، وبيّن سبب كل انتقال رياضي. إذا سأل الطالب عن خطوة سابقة، اشرح تلك الخطوة تحديداً مع الحفاظ على سياق المحادثة.
عند قراءة صورة، انقل السؤال أو الرموز التي أمكن تمييزها أولاً؛ إذا كان جزء غير واضح فاطلب صورة أوضح ولا تخمّن المعطيات.
راعِ أسلوب الحل المدرسي الأردني، لكن لا تخترع أرقام وحدات أو صفحات أو نصوصاً رسمية للمنهاج. إذا كانت صيغة السؤال أو فرضياته ناقصة فاذكر ذلك واسأل عنها. لا تدّعِ أن الناتج مضمون الصحة؛ أظهر خطوات تمكّن الطالب من مراجعته."""
PREV = {}

class Task:
    def __init__(self, chat, text, files=None, mode="auto"):
        self.chat, self.text, self.files, self.mode = chat, text, files or [], mode if mode in ("auto", "chat", "code", "math", "media", "ollama") else "auto"
        self.events, self.pending = [], {}
        self.cv, self.done, self.cancel = threading.Condition(), False, False
        threading.Thread(target=self._run, daemon=True).start()

    def emit(self, type, **kw):
        with self.cv: self.events.append({"i": len(self.events), "type": type, **kw}); self.cv.notify_all()

    def approve(self, cid, ok):
        ev = self.pending.get(cid)
        if ev: ev["ok"] = ok; ev["e"].set()

    def _ask(self, cid, name, args):
        ev = self.pending[cid] = {"e": threading.Event(), "ok": False}
        self.emit("approval", id=cid, name=name, input=args)
        ev["e"].wait(300); self.pending.pop(cid, None); return ev["ok"]

    def _direct_website(self):
        text = self.text.strip()
        if not re.search(r"(?:اعمل|اصنع|أنشئ|ابن|صمّم|صمم|أنشئ\s+لي).{0,20}(?:موقع|صفحة|landing|website|site|ويب)", text, re.I):
            return False
        lang = "en" if re.search(r"\b(website|landing page|portfolio|HTML|CSS|JavaScript)\b", text, re.I) and not re.search(r"[ء-ي]", text) else "ar"
        theme_match = re.search(r"(blue|violet|green|orange|pink|أزرق|بنفسجي|اخضر|أخضر|برتقالي|وردي)", text, re.I)
        themes = {"أزرق": "blue", "بنفسجي": "violet", "اخضر": "green", "أخضر": "green", "برتقالي": "orange", "وردي": "pink"}
        theme = theme_match.group(1).lower() if theme_match else "blue"
        theme = themes.get(theme, theme)
        if theme not in ("blue", "green", "orange", "pink", "violet"):
            theme = "blue"

        name_match = re.search(r"(?:لموقع|لمشروع|اسم(?:ه|ها)?|تسمية)\s*[:：]?\s*['\"]?([^,\n]+)", text, re.I)
        name = name_match.group(1).strip() if name_match else ("موقع احترافي" if lang == "ar" else "Professional Website")
        name = re.sub(r"\s+(?:بألوان?|باستخدام|بتصميم|في)\s+.+$", "", name).strip(" .,:")
        folder_match = re.search(r"(?:باسم|مجلد)\s+([A-Za-z0-9_-]+)", text, re.I)
        folder = folder_match.group(1) if folder_match else "website"
        if lang == "ar":
            tagline = "تصميم احترافي، تجربة سريعة وتجربة متجاوبة"
            about = "نقدّم حلولاً عصرية مصممة بعناية لتناسب احتياجاتك ومشاريعك."
            features = ["تصميم عصري|واجهة أنيقة وتفاصيل احترافية", "سرعة وأداء|محتوى سريع وواضح", "متجاوب|يعمل بشكل ممتاز على الهاتف والحاسوب"]
            contact = "يسعدنا التواصل معك ومناقشة مشروعك"
        else:
            tagline = "Professional, fast and responsive digital experience"
            about = "We create modern solutions designed carefully for your goals."
            features = ["Modern design|Clean and professional interface", "Fast performance|Clear and optimized experience", "Responsive|Works on every screen"]
            contact = "Let's discuss your project"
        args = {"name": name[:80], "tagline": tagline, "about": about, "features": features,
                "folder": folder, "theme": theme, "lang": lang, "contact": contact}
        result = self._exec("make_website", args)
        if not str(result).startswith("تم"):
            self.emit("error", text=str(result))
        else:
            self.emit("notice", text=f"معاينة الموقع: /preview/{folder}/index.html")
            self.emit("final")
        return True

    def _direct_media(self):
        text = self.text.lower()
        media_action = r"(?:اعمل|اصنع|صمم|أنشئ|توليد|عمل|generate|create|make|draw|render|جهز|جهّز)"
        is_image = bool(re.search(media_action, text, re.I) and re.search(r"(?:صورة|صور|غلاف|بوستر|image|picture|cover|poster)", text, re.I))
        is_video = bool(re.search(media_action, text, re.I) and re.search(r"(?:فيديو|ريل|ريلز|مونتاج|video|reel|tiktok|render|قص)", text, re.I))
        if not (is_image or is_video):
            return False

        uploaded = []
        for item in self.files:
            path = config.WORKSPACE / item["path"]
            if path.is_file():
                uploaded.append(path.relative_to(config.WORKSPACE).as_posix())

        wants_cover_only = is_image and bool(re.search(r"(?:غلاف|بوستر|cover|poster)", text, re.I))
        if is_video and not wants_cover_only:
            sources = uploaded[:]
            if not sources:
                for ext in (".png", ".jpg", ".jpeg", ".webp"):
                    sources.extend(p.relative_to(config.WORKSPACE).as_posix()
                                   for p in sorted(config.WORKSPACE.glob("*" + ext))[:8])
            if not sources:
                cover = "datax_auto_cover.png"
                args = {"title": "DATA X", "subtitle": "صنع بواسطة DATA X", "preset": "reel", "theme": "violet", "out": cover}
                result = self._exec("make_cover", args)
                if (config.WORKSPACE / cover).is_file():
                    sources = [cover]
            reel_out = re.search(r"([A-Za-z0-9_\-]+\.mp4)", self.text, re.I)
            args = {"items": sources, "out": reel_out.group(1) if reel_out else "datax_reel.mp4", "seconds_per_image": 3}
            result = self._exec("make_reel", args)
            if not str(result).startswith("تم إنشاء الريلز"):
                self.emit("error", text=str(result))
            else:
                self.emit("final")
            return True

        if is_image:
            named = re.search(r"([A-Za-z0-9_\-]+\.(?:png|jpg|jpeg|webp))", self.text, re.I)
            out = named.group(1) if named else ("cover.png" if "غلاف" in text or "cover" in text else "datax_image.png")
            if "غلاف" in text or "cover" in text or "بوستر" in text or "poster" in text:
                title = "DATA X"
                patterns = (
                    r"(?:بعنوان|عنوان)\s*[:：]?\s*['\"]?([^,'\"\n]+)",
                    r"(?:غلاف|بوستر|cover|poster)\s+(?:عن|لفريق|ل)\s*([^,\n]+)",
                )
                for pattern in patterns:
                    m = re.search(pattern, self.text, re.I)
                    if m:
                        title = m.group(1).strip()[:100]
                        break
                title = re.sub(r"\s+(?:باسم|اسم)\s+[A-Za-z0-9_.\-]+\.(?:png|jpg|jpeg|webp)\s*$", "", title, flags=re.I).strip()
                subtitle = "DATA X" if title == "DATA X" else "تصميم احترافي"
                result = self._exec("make_cover", {"title": title, "subtitle": subtitle, "preset": "reel" if "ريل" in text or "reel" in text else "post", "theme": "violet", "out": out})
            else:
                prompt = " ".join(self.text.split())
                names = {
                    "سبونج بوب": "SpongeBob SquarePants",
                    "سبونجبوب": "SpongeBob SquarePants",
                    "ميكي ماوس": "Mickey Mouse",
                    "باتمان": "Batman",
                    "سوبرمان": "Superman",
                }
                for ar_name, en_name in names.items():
                    prompt = re.sub(ar_name, en_name, prompt, flags=re.I)
                prompt = re.sub(r"(?:اعمل(?:لي| لي)?|اصنع(?:لي| لي)?|صمم(?:لي| لي)?|عمل(?:لي| لي)?|توليد|generate|create|make)\s*", " ", prompt, flags=re.I)
                prompt = " ".join(prompt.split())
                prompt = "professional high quality cartoon illustration, " + prompt[:400] + ", detailed, polished, clean composition"
                result = self._exec("ai_image", {"prompt": prompt, "out": out, "width": 1024, "height": 1024})
            if not str(result).startswith(("تم إنشاء", "تم تعديل")):
                self.emit("error", text=str(result))
            else:
                self.emit("final")
            return True

    def _direct_code_file(self):
        text = self.text.strip()
        match = re.search(r"(?:اكتب|أنشئ|اصنع|اعمل)\s+(?:ملف|كود)\s+(?:بايثون|python)?\s*(?:باسم|اسم(?:ه)?|يسمى)?\s*[:：]?\s*([A-Za-z0-9_.\-/\\]+\.(?:py|js|ts|tsx|jsx|html|css|json|sql|java|c|cpp|go|rs|php|sh|bat))", text, re.I)
        if not match:
            return False
        filename = match.group(1).replace("\\", "/")
        filename = pathlib.PurePosixPath(filename).name
        ext = pathlib.Path(filename).suffix.lower()
        content = ""
        if ext == ".py" and re.search(r"sum_numbers|جمع|المجموع|تجمع", text, re.I):
            content = '''def sum_numbers(numbers):\n    """Returns the sum of a list of numbers."""\n    return sum(numbers)\n\n\nif __name__ == "__main__":\n    assert sum_numbers([1, 2, 3, 4, 5]) == 15\n    print(sum_numbers([1, 2, 3, 4, 5]))\n'''
        elif ext == ".py" and re.search(r"(multiply|ضرب|حاصل الضرب)", text, re.I):
            content = '''def multiply(a, b):\n    """Returns the product of two numbers."""\n    return a * b\n\n\nif __name__ == "__main__":\n    assert multiply(6, 7) == 42\n    print(multiply(6, 7))\n'''
        elif ext == ".py":
            content = "#!/usr/bin/env python3\n\n\ndef main():\n    print(\"Hello from DATA X\")\n\n\nif __name__ == \"__main__\":\n    main()\n"
        elif ext in (".js", ".jsx"):
            content = "function main() {\n  console.log(\"Hello from DATA X\");\n}\n\nmain();\n"
        elif ext == ".ts":
            content = "function main(): void {\n  console.log(\"Hello from DATA X\");\n}\n\nmain();\n"
        elif ext == ".html":
            content = "<!DOCTYPE html>\n<html lang=\"ar\" dir=\"rtl\">\n<head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><title>DATA X</title></head>\n<body><h1>DATA X</h1></body>\n</html>\n"
        else:
            content = "// Created by DATA X\n"
        result = self._exec("write_file", {"path": filename, "content": content})
        if not str(result).startswith("تمت الكتابة"):
            self.emit("error", text=str(result))
        else:
            self.emit("final")
        return True

    def _run(self):
        try: self._loop()
        except urllib.error.URLError: self.emit("error", text="Ollama غير شغال. افتح برنامج Ollama (أو شغّل START_DATAX.bat) ثم أعد المحاولة.")
        except Exception as e: self.emit("error", text=f"{type(e).__name__}: {e}")
        finally:
            with self.cv: self.done = True; self.cv.notify_all()

    def _exec(self, name, args):
        cid = uuid.uuid4().hex[:8]; self.emit("tool", name=name, input=args)
        if name in tools.REG and tools.needs_approval(name, args, config.load()["auto_approve"]) and not self._ask(cid, name, args):
            self.emit("result", name=name, text="رُفضت العملية", files=[]); return "رفض المستخدم تنفيذ هذه العملية."
        tools.begin(); out = str(tools.run(name, args)); files = tools.end()
        self.emit("result", name=name, text=out[:400], files=files); return out

    def _video_images(self, path):
        exe = config.find_exe("ffmpeg")
        if not exe: raise RuntimeError("فهم الفيديو يتطلب FFmpeg؛ شغّل START_DATAX.bat أو ثبّته من ffmpeg.org")
        with tempfile.TemporaryDirectory() as folder:
            pattern = pathlib.Path(folder) / "frame-%02d.jpg"
            command = [exe, "-hide_banner", "-loglevel", "error", "-i", str(path), "-vf", "fps=1/3,scale=768:-1", "-frames:v", "4", str(pattern)]
            result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180, creationflags=config.NOWIN)
            frames = sorted(pathlib.Path(folder).glob("frame-*.jpg"))
            if result.returncode or not frames:
                raise RuntimeError("تعذر استخراج إطارات من الفيديو: " + result.stderr[-300:])
            return [base64.b64encode(frame.read_bytes()).decode("ascii") for frame in frames]

    def _user_message(self, content):
        if isinstance(content, str): return {"role": "user", "content": content}
        text = content.get("content", "")
        images = []
        for item in content.get("attachments", []):
            path = attachments.resolve_path(item["path"])
            ext = path.suffix.lower()
            if not path.is_file(): raise RuntimeError(f"تعذر العثور على المرفق: {item['name']}")
            if ext in attachments.IMAGE_EXTS:
                images.append(base64.b64encode(path.read_bytes()).decode("ascii"))
                text += f"\n[صورة مرفقة: {item['name']}؛ مسارها داخل مجلد العمل: {item['path']}]"
            elif ext in attachments.VIDEO_EXTS:
                images.extend(self._video_images(path))
                text += f"\n[إطارات مستخرجة من الفيديو المرفق: {item['name']}؛ مساره داخل مجلد العمل: {item['path']}]"
            elif ext in attachments.TEXT_EXTS or ext in attachments.DOC_EXTS:
                extracted = attachments.extract_text(path)
                text += f"\n\n[محتوى الملف {item['name']}]\n{extracted}\n[نهاية الملف]"
            else:
                text += f"\n[مرفق محفوظ في مجلد العمل: {item['path']}؛ الصيغة غير مدعومة للقراءة التلقائية]"
        message = {"role": "user", "content": text}
        if images: message["images"] = images
        return message

    def _loop(self):
        s = config.load()
        self.text = self.text or "حلّل المرفقات واشرح محتواها، أو نفّذ المطلوب عليها."
        if self.mode in ("auto", "code"):
            direct_code = self._direct_code_file()
            if direct_code:
                db.add(self.chat, "user", {"content": self.text, "attachments": self.files} if self.files else self.text)
                return
        if self.mode in ("auto", "code"):
            direct_website = self._direct_website()
            if direct_website:
                db.add(self.chat, "user", {"content": self.text, "attachments": self.files} if self.files else self.text)
                return
        if self.mode == "media" or self.mode == "auto":
            direct_media = self._direct_media()
        else:
            direct_media = False
        if direct_media:
            db.add(self.chat, "user", {"content": self.text, "attachments": self.files} if self.files else self.text)
            return
        memory_match = re.search(r"(?:تذكر(?:ني| أن)?|احفظ(?:لي| أن)?|remember that|remember:)\s*(.+)", self.text, re.I)
        if memory_match:
            db.remember("explicit", memory_match.group(1).strip(), self.chat)
        auto_patterns = (
            r"(?:اسمي|أنا اسمي)\s+(.+)",
            r"(?:أفضّل|أفضل)\s+(.+)",
            r"(?:my name is|i prefer|always)\s+(.+)",
        )
        for pattern in auto_patterns:
            match = re.search(pattern, self.text, re.I)
            if match:
                db.remember("preference", match.group(1).strip()[:150], self.chat)
        db.add(self.chat, "user", {"content": self.text, "attachments": self.files} if self.files else self.text)
        history = db.load(self.chat)[-10:]
        msgs = []
        for item in history:
            if item["role"] == "tool": continue
            content = item["content"]
            if item["role"] == "user": msgs.append(self._user_message(content))
            elif isinstance(content, dict): msgs.append({"role": item["role"], **content})
            else: msgs.append({"role": item["role"], "content": content})
        while msgs and msgs[0]["role"] != "user": msgs.pop(0)
        visual = any(m.get("images") for m in msgs)
        if llm.models() is None: raise urllib.error.URLError("down")
        attachment_names = " ".join(item["name"] for item in self.files)
        names = tools.select(self.text + " " + attachment_names, PREV.get(self.chat)); PREV[self.chat] = names
        schemas = [tools.REG[n]["schema"] for n in names]; use_tools = bool(schemas)
        if visual:
            model = llm.vision_model()
            llm.ensure_model(model)
            # لا تُرسل قائمة أدوات للنماذج البصرية:
            # Ollama يرفض الطلبات المتعددة الوسائط مع tool schemas.
            use_tools = False
            schemas = []
        else:
            model = llm.route_model(self.text, self.mode, visual=False, settings=s)
            if model:
                try:
                    llm.ensure_model(model)
                except Exception:
                    if self.mode == "math":
                        raise
                    pass
        if not model:
            status = llm.STATE["msg"]
            if status:
                if status.startswith(("فشل", "تعذّر", "تعذر")): raise RuntimeError(status)
                raise RuntimeError("انتظر حتى يكتمل تجهيز النموذج: " + status)
            wanted = s["model"] if s["model"] != "auto" else llm.recommended()
            raise RuntimeError(f"النموذج {wanted} غير منزّل. أعد تشغيل DATA X لتنزيله أو اختر نموذجاً متاحاً من الإعدادات.")
        k = knowledge.lookup(self.text)
        memory = db.memories(self.chat)
        memory_text = "\n".join(f"- {m['kind']}: {m['value']}" for m in memory) or "(لا توجد معلومات محفوظة بعد)"
        sysmsg = SYSTEM.format(ws=config.WORKSPACE, memory=memory_text)
        if self.mode == "math":
            sysmsg += "\n\n" + MATH_TUTOR
        if k:
            sysmsg += "\n\n# مراجع\n" + k
        vision_attempted = {model} if visual else set()
        for _ in range(s["max_steps"]):
            if self.cancel: return self.emit("error", text="تم الإيقاف")
            text, calls = "", []
            try:
                for d in llm.stream(model, msgs, schemas if use_tools else None, sysmsg, s["ctx"]):
                    m = d.get("message", {})
                    if m.get("content"): text += m["content"]; self.emit("token", text=m["content"])
                    calls += m.get("tool_calls") or []
                    if d.get("eval_count") and d.get("eval_duration"): self.emit("stats", text=f"{d['eval_count'] / d['eval_duration'] * 1e9:.1f} tok/s · {model}")
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "replace")
                if visual and (e.code == 400 or "multimodal" in body.lower()):
                    switched = False
                    for candidate in llm.VISION_MODELS:
                        if candidate in vision_attempted:
                            continue
                        try:
                            llm.ensure_model(candidate)
                            model = candidate
                            vision_attempted.add(candidate)
                            switched = True
                            self.emit("notice", text=f"تبديل إلى نموذج الرؤية البديل: {candidate}")
                            break
                        except Exception:
                            vision_attempted.add(candidate)
                    if switched:
                        continue
                if e.code == 404: raise RuntimeError(f"النموذج {model} غير منزّل. نفّذ: ollama pull {model}")
                if use_tools and "tool" in body.lower(): use_tools = False; self.emit("notice", text="هذا النموذج لا يدعم الأدوات، سأجيب بالنص فقط."); continue
                raise RuntimeError(f"Ollama {e.code}: {body[:300]}")
            if use_tools and not calls:
                calls, clean = llm.text_calls(text, tools.REG)
                if calls: text = clean; self.emit("replace", text=clean)
            a = {"content": text}
            if calls: a["tool_calls"] = calls
            msgs.append({"role": "assistant", **a}); db.add(self.chat, "assistant", a); self.emit("msg_end")
            if not calls: return self.emit("final")
            for c in calls:
                f = c["function"]; args = f.get("arguments") or {}
                if isinstance(args, str):
                    try: args = json.loads(args)
                    except Exception: args = {}
                out = self._exec(f["name"], args if isinstance(args, dict) else {})[:2000]
                msgs.append({"role": "tool", "tool_name": f["name"], "content": out}); db.add(self.chat, "tool", {"tool_name": f["name"], "content": out})
        self.emit("error", text="وصلت للحد الأقصى من الخطوات. اكتب «أكمل» للمتابعة.")

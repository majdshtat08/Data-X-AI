import io, os, subprocess, sys, tempfile
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
os.environ["APPDATA"] = tempfile.mkdtemp(); sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datax import config, tools, llm; tools.load_plugins()
s = tools.select
assert s("مرحبا كيفك اليوم") == [] and s("hello how are you") == []                 # دردشة عادية: بدون أدوات = سريع
assert {"write_file", "open_target"} <= set(s("اعمل لي موقع احترافي")) and "make_reel" not in s("اعمل لي موقع")
assert {"make_cover", "make_reel"} <= set(s("صمم غلاف وجهز ريل")) and "word_count" in s("اعمل ريل")  # الإضافات تُضاف
assert s("أكمل", ["write_file"]) == ["write_file"]                                  # المتابعة تحتفظ بأدوات الطلب السابق
assert "make_reel" in s("اعمل ريل من demo.mp4")
assert llm.route_model("اصنع موقعاً ببايثون", "code", False, {"model":"auto"}) in (llm.CODER_MODELS + ("qwen2.5-coder:3b",))
original_ram = llm.ram_gb
llm.ram_gb = lambda: 32
assert llm.route_model("أوجد مشتقة الدالة", "math", False, {"model":"auto"}) == "qwen3:8b"
llm.ram_gb = lambda: 8
assert llm.route_model("أوجد مشتقة الدالة", "math", False, {"model":"auto"}) == "qwen2.5:3b"
llm.ram_gb = original_ram
assert llm.route_model("أوجد مشتقة الدالة", "math", True, {"model":"auto"}) == "qwen2.5vl:3b"
original_models = llm.models
llm.models = lambda: ["qwen2.5:3b"]
assert llm.route_model("أوجد مشتقة الدالة", "math", False, {"model":"qwen2.5:3b"}) == "qwen2.5:3b"
llm.models = original_models
from unittest.mock import patch
setup_models = []
def ensure_with_missing_math(model):
    setup_models.append(model)
    if model == "qwen2.5:3b":
        raise RuntimeError("نموذج الرياضيات غير متاح")
with patch.object(llm, "ensure_ollama", return_value=True), \
     patch.object(llm, "ensure_model", side_effect=ensure_with_missing_math), \
     patch.object(llm, "warmup"), \
     patch.object(llm, "vision_model", return_value="qwen2.5vl:3b"), \
     patch.object(llm, "math_model", return_value="qwen2.5:3b"), \
     patch.object(llm, "models", return_value=[]), \
     patch.object(config, "find_exe", return_value="installed"), \
     patch.object(llm, "winget", return_value=True):
    llm.STATE["msg"] = ""
    llm.background_setup()
    assert "qwen2.5:3b" in llm.STATE["msg"]
    assert "smollm2:1.7b" in setup_models and "qwen2.5-coder:1.5b" in setup_models and "qwen2.5vl:3b" in setup_models

class CompletedPull:
    stdout = io.StringIO("pulling model 100%\n")
    def wait(self, timeout=None): return 0
    def kill(self): raise AssertionError("successful pull should not be killed")

with patch.object(llm, "models", side_effect=[[], ["qwen2.5:3b"]]), \
     patch.object(config, "find_exe", return_value="ollama"), \
     patch.object(llm.subprocess, "Popen", return_value=CompletedPull()):
    llm.ensure_model("qwen2.5:3b")

class TimedOutPull:
    stdout = io.StringIO("")
    def wait(self, timeout=None):
        if timeout is not None:
            raise subprocess.TimeoutExpired("ollama pull", timeout)
        return -9
    def kill(self): pass

with patch.object(llm, "models", return_value=[]), \
     patch.object(config, "find_exe", return_value="ollama"), \
     patch.object(llm.subprocess, "Popen", return_value=TimedOutPull()):
    try:
        llm.ensure_model("qwen2.5:3b")
        raise AssertionError("timed out model download should fail")
    except RuntimeError as error:
        assert "انتهت مهلة تنزيل" in str(error)
print("اختبار التوجيه نجح ✅")

# --- المعرفة ومولّد المواقع ---
import html.parser, pathlib
from datax import knowledge, tools as T, config
assert knowledge.lookup("hello") == "" and knowledge.lookup("مرحبا") == ""
assert "grid" in knowledge.lookup("make css grid layout").lower() and "make_website" in knowledge.lookup("اعمل لي موقع")
assert "github" in knowledge.lookup("كيف انشر على github pages").lower() and len(knowledge.lookup("موقع css javascript python")) <= 2200
r = T.run("make_website", {"name": "Data X Team", "tagline": "برمجة وتصميم", "about": "فريق", "features": "سريع|وصف\nعصري|وصف2", "folder": "tsite", "theme": "violet", "lang": "ar"})
d = config.WORKSPACE / "tsite"; assert "تم" in r and all((d / f).exists() for f in ("index.html", "style.css", "script.js")), r
page = (d / "index.html").read_text("utf-8"); assert 'dir="rtl"' in page and page.count('class="card') == 2 and "<script" in page
class Chk(html.parser.HTMLParser):
    def __init__(s): super().__init__(); s.st = []
    def handle_starttag(s, t, a):
        if t not in ("meta", "link", "br", "img", "input"): s.st.append(t)
    def handle_endtag(s, t): assert s.st and s.st.pop() == t, t
c = Chk(); c.feed(page); assert not c.st, c.st                                  # HTML متوازن
assert "__" not in page and "__" not in (d / "style.css").read_text("utf-8")    # لا بقايا قوالب
assert 'dir="ltr"' in (T.run("make_website", {"name": "A", "folder": "e", "lang": "en"}) and (config.WORKSPACE / "e/index.html").read_text("utf-8"))
print("اختبار المعرفة والمواقع نجح ✅")

# إنشاء موقع مباشر من العربية واختبار اكتمال الملفات
import threading
from datax.agent import Task
direct = Task.__new__(Task)
direct.text = "اعمل لي موقع شركة برمجة احترافي بألوان زرقاء"
direct.files = []
direct.events = []
direct.cv = threading.Condition()
direct.pending = {}
direct.done = False
assert direct._direct_website() is True
assert all((config.WORKSPACE / "website" / f).exists() for f in ("index.html", "style.css", "script.js"))
assert any(e["type"] == "final" for e in direct.events)
print("اختبار إنشاء الموقع المباشر والمعاينة نجح ✅")

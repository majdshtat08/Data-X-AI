import json, sqlite3, threading, time
from .config import HOME
_c = sqlite3.connect(HOME / "history.db", check_same_thread=False); _l = threading.Lock()
_c.execute("create table if not exists msgs(id integer primary key, chat text, role text, content text, ts real)")
_c.execute("create table if not exists chat_meta(chat text primary key, title text, updated_at real)")
_c.execute("create table if not exists memories(id integer primary key, kind text, value text, chat text, ts real)")
def add(chat, role, content):
    with _l: _c.execute("insert into msgs(chat,role,content,ts) values(?,?,?,?)", (chat, role, json.dumps(content, ensure_ascii=False), time.time())); _c.commit()
    if role == "user":
        raw = content.get("content", "") if isinstance(content, dict) else str(content)
        if isinstance(content, dict):
            names = [a.get("name", "") for a in content.get("attachments", []) if isinstance(a, dict)]
            if not raw.strip() and names:
                raw = "مرفقات: " + "، ".join(names[:3])
        title = " ".join(raw.replace("\n", " ").strip().split())[:40]
        if title:
            _c.execute("insert into chat_meta(chat,title,updated_at) values(?,?,?) on conflict(chat) do update set title=excluded.title,updated_at=excluded.updated_at",
                       (chat, title, time.time()))
            _c.commit()
def load(chat):
    with _l: rows = _c.execute("select role,content from msgs where chat=? order by id", (chat,)).fetchall()
    return [{"role": r, "content": json.loads(c)} for r, c in rows]
def chats():
    q = "select m.chat,coalesce(cm.title,(select content from msgs b where b.chat=m.chat and b.role='user' order by id limit 1)) from msgs m left join chat_meta cm on cm.chat=m.chat group by m.chat order by max(m.ts) desc limit 50"
    out = []
    with _l: rows = _c.execute(q).fetchall()
    for c, t in rows:
        try: t = json.loads(t)
        except Exception: t = ""
        if isinstance(t, dict):
            text = t.get("content", "")
            names = [a.get("name", "") for a in t.get("attachments", []) if isinstance(a, dict)]
            t = text or ("مرفقات: " + "، ".join(names[:3]) if names else "")
        out.append({"id": c, "title": (" ".join(str(t).replace("\n", " ").split())[:40] or c)})
    return out
def delete(chat):
    with _l:
        _c.execute("delete from msgs where chat=?", (chat,))
        _c.execute("delete from chat_meta where chat=?", (chat,))
        _c.execute("delete from memories where chat=?", (chat,))
        _c.commit()

def remember(kind, value, chat=""):
    value = " ".join(str(value).strip().split())[:300]
    if not value: return
    with _l:
        _c.execute("delete from memories where kind=? and value=?", (kind, value))
        _c.execute("insert into memories(kind,value,chat,ts) values(?,?,?,?)", (kind, value, chat, time.time()))
        _c.commit()

def memories(chat="", limit=20):
    with _l:
        if chat:
            rows = _c.execute("select kind,value from memories where chat=? or chat='' order by ts desc limit ?", (chat, limit)).fetchall()
        else:
            rows = _c.execute("select kind,value from memories order by ts desc limit ?", (limit,)).fetchall()
    return [{"kind": r[0], "value": r[1]} for r in rows]

def forget(chat=""):
    with _l:
        if chat:
            _c.execute("delete from memories where chat=?", (chat,))
        else:
            _c.execute("delete from memories")
        _c.commit()

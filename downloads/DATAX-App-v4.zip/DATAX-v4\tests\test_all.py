import base64, io, json, os, shutil, subprocess, sys, tempfile, threading, time, urllib.request, zipfile
if hasattr(sys.stdout, "reconfigure"): sys.stdout.reconfigure(encoding="utf-8")
os.environ["APPDATA"] = tempfile.mkdtemp(); sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer
from datax import config, llm, tools, server, db
from datax.agent import Task
tools.load_plugins(); W = config.WORKSPACE
PLAN, N, TAGS, BODIES = [], [0], ["glm-5.3-flash:cloud", "qwen2.5:7b", "qwen2.5:3b", "qwen2.5vl:3b"], []
def call(n, a): return {"tool_calls": [{"function": {"name": n, "arguments": a}}]}
class Fake(BaseHTTPRequestHandler):  # Ollama وهمي مع بث NDJSON
    def log_message(self, *a): pass
    def do_GET(self):
        b = json.dumps({"models": [{"name": t} for t in TAGS]}).encode(); self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_POST(self):
        raw = self.rfile.read(int(self.headers["Content-Length"]))
        if self.path == "/api/chat": BODIES.append(json.loads(raw))
        self.send_response(200); self.end_headers()
        if self.path != "/api/chat": return self.wfile.write(b"{}")
        step = PLAN[N[0]]; N[0] += 1
        for part in step["say"]: self.wfile.write((json.dumps({"message": {"role": "assistant", "content": part}, "done": False}) + "\n").encode())
        self.wfile.write((json.dumps({"message": {"role": "assistant", "content": "", **{k: v for k, v in step.items() if k == "tool_calls"}}, "done": True}) + "\n").encode())
srv = ThreadingHTTPServer(("127.0.0.1", 0), Fake); threading.Thread(target=srv.serve_forever, daemon=True).start()
config.save({**config.load(), "ollama_url": f"http://127.0.0.1:{srv.server_port}"})
def wait(t, c):
    for _ in range(200):
        if c(): return
        time.sleep(0.05)
    raise AssertionError(t.events)

# 1) اختيار النموذج تلقائياً (لا يختار نموذج الكلاود أبداً)
llm.ram_gb = lambda: 32; assert llm.pick() == "qwen2.5:7b"
llm.ram_gb = lambda: 8;  assert llm.pick() == "qwen2.5:3b"
assert llm.text_calls('x <tool_call>{"name":"list_dir","arguments":{}}</tool_call>', tools.REG)[0][0]["function"]["name"] == "list_dir"

# 2) وكيل: بث نصي + أداة رسمية + أداة مكتوبة كنص + حذف بموافقة
PLAN[:] = [{"say": ["سأ", "نشئ"], **call("write_file", {"path": "site/index.html", "content": "<h1>DATA X</h1>"})},
           {"say": ['<tool_call>{"name":"list_dir","arguments":{"path":"site"}}</tool_call>'], },
           {"say": [""], **call("delete_path", {"path": "site/index.html"})}, {"say": ["تم ", "كل شي"]}]
N[0] = 0; t = Task("t1", "أنشئ ملف HTML تجريبي")
wait(t, lambda: any(e["type"] == "approval" for e in t.events)); assert (W / "site/index.html").exists()
t.approve([e for e in t.events if e["type"] == "approval"][0]["id"], True); wait(t, lambda: t.done)
ev = [e["type"] for e in t.events]
assert "token" in ev and "replace" in ev and ev[-1] == "final" and not (W / "site/index.html").exists(), t.events
assert any(e["type"] == "result" and e["files"] == ["site/index.html"] for e in t.events)

# 3) الرفض لا يحذف
(W / "k.txt").write_text("x"); PLAN[:] = [{"say": [""], **call("delete_path", {"path": "k.txt"})}, {"say": ["حسناً"]}]; N[0] = 0
t = Task("t2", "احذف"); wait(t, lambda: any(e["type"] == "approval" for e in t.events))
t.approve([e for e in t.events if e["type"] == "approval"][0]["id"], False); wait(t, lambda: t.done); assert (W / "k.txt").exists()
assert tools.needs_approval("run_command", {"command": "Remove-Item x"}, True) and not tools.needs_approval("run_command", {"command": "dir"}, True)

# 4) فيديو حقيقي بـ ffmpeg
if shutil.which("ffmpeg"):
    for n in "ab": subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "color=c=blue:s=640x480", "-frames:v", "1", str(W / f"{n}.png")], check=True)
    from unittest.mock import patch
    class ImageResponse:
        def __enter__(self): return self
        def __exit__(self, *args): pass
        def read(self): return (W / "a.png").read_bytes()
    with patch.object(tools.urllib.request, "urlopen", return_value=ImageResponse()):
        assert "تم إنشاء الصورة" in tools.ai_image("blue art", "remote-image.jpg", 128, 128)
    assert (W / "remote-image.jpg").read_bytes().startswith(b"\xff\xd8\xff")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=s=1280x720:d=2", str(W / "c.mp4")], check=True)
    r = tools.run("make_reel", {"items": ["a.png", "b.png", "c.mp4"], "out": "r.mp4", "seconds_per_image": 1}); assert "تم" in r, r
    pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=width,height,duration", "-of", "csv=p=0", str(W / "r.mp4")], capture_output=True, text=True).stdout
    assert "1080,1920" in pr, pr; print("ريلز:", pr.strip())
    assert "تم تعديل الصورة" in tools.run("edit_image", {"path": "a.png", "operation": "grayscale", "out": "gray.png"})
    assert (W / "gray.png").is_file()
    assert "تم" in tools.run("video_trim", {"path": "c.mp4", "start": "0", "end": "1", "out": "tr.mp4"})
    assert "تم" in tools.run("video_to_reel", {"path": "c.mp4", "out": "cut.mp4"})
else: print("(ffmpeg غير موجود هنا)")
if tools.browser(): print(tools.run("make_cover", {"title": "فريق DATA X", "subtitle": "برمجة وتصميم", "preset": "reel", "out": "cv.png"}))
else: print("(لا متصفح هنا لاختبار الأغلفة)")

# 5) الخادم: صحة، بث SSE، ملفات آمنة
PLAN[:] = [{"say": ["مرحبا ", "بك"]}]; N[0] = 0
web = ThreadingHTTPServer(("127.0.0.1", 0), server.H); web.daemon_threads = True; threading.Thread(target=web.serve_forever, daemon=True).start(); B = f"http://127.0.0.1:{web.server_port}"
g = lambda p: urllib.request.urlopen(B + p).read()
h = json.loads(g("/api/health")); assert h["ollama"] and h["model"] in ("qwen2.5:7b", "qwen2.5:3b") and h["math_model"] in ("qwen3:8b", "qwen2.5:3b"), h
zip_data = g("/api/export_zip")
with zipfile.ZipFile(io.BytesIO(zip_data)) as archive:
    names = archive.namelist()
    assert names and all(name.startswith("DataX-Files/") for name in names), names
    assert not any("/.tmp/" in name for name in names), names
r = json.loads(urllib.request.urlopen(urllib.request.Request(B + "/api/chat", json.dumps({"text": "hi"}).encode(), {"Content-Type": "application/json"})).read())
body = g("/api/stream?task=" + r["task"]).decode(); assert '"type": "token"' in body and "event: end" in body, body
assert json.loads(g("/api/chats"))[0]["title"] == "hi"
db.remember("preference", "يفضل التصميم الداكن", "memory-test")
assert db.memories("memory-test")[0]["value"] == "يفضل التصميم الداكن"
PLAN[:] = [{"say": ["تم تحليل الصورة"]}]; N[0] = 0
fake_png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16
upload = {"text": "اشرح الصورة", "files": [{"name": "photo.png", "data": base64.b64encode(fake_png).decode("ascii")}]}
r = json.loads(urllib.request.urlopen(urllib.request.Request(B + "/api/chat", json.dumps(upload).encode(), {"Content-Type": "application/json"})).read())
body = g("/api/stream?task=" + r["task"]).decode()
assert "تم تحليل الصورة" in body and BODIES[-1]["messages"][-1]["images"] == [base64.b64encode(fake_png).decode("ascii")], body
saved = W / r["attachments"][0]["path"]; assert saved.read_bytes() == fake_png
history = json.loads(g("/api/history?chat=" + r["chat"])); assert history[0]["attachments"][0]["path"] == r["attachments"][0]["path"]
try: g("/files/..%2f..%2fetc/passwd"); raise SystemExit("ثغرة!")
except urllib.error.HTTPError as e: assert e.code in (403, 404)
try: urllib.request.urlopen(urllib.request.Request(B + "/api/chat", b"{}", {"Origin": "http://evil.com"})); raise SystemExit("ثغرة!")
except urllib.error.HTTPError as e: assert e.code == 403
import threading
direct = Task.__new__(Task); direct.text = "اعمل غلاف ريل لفريق DATA X"; direct.files = []; direct.events = []; direct.cv = threading.Condition(); direct.pending = {}; direct.done = False
assert direct._direct_media() is True
assert any(e["type"] == "final" for e in direct.events)

# النماذج البصرية يجب ألا تتلقى tool schemas مع الصور.
def vision_route_check():
    original_ensure = llm.ensure_model
    original_vision = llm.vision_model
    original_pick = llm.pick
    llm.ensure_model = lambda model: None
    llm.vision_model = lambda: "qwen2.5vl:3b"
    llm.pick = lambda s=None: "qwen2.5:3b"
    PLAN[:] = [{"say": ["تم تحليل الصورة"]}]
    N[0] = 0
    fake_png = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16
    upload = {"text": "حلل الصورة واشرحها", "mode": "math", "files": [{"name": "photo.png", "data": base64.b64encode(fake_png).decode("ascii")}]}
    r = json.loads(urllib.request.urlopen(urllib.request.Request(B + "/api/chat", json.dumps(upload).encode(), {"Content-Type": "application/json"})).read())
    body = g("/api/stream?task=" + r["task"]).decode()
    assert "تم تحليل الصورة" in body
    sent = BODIES[-1]
    assert "tools" not in sent
    assert sent["model"] == "qwen2.5vl:3b"
    assert "التوجيهي الأردني" in sent["messages"][0]["content"]
    llm.ensure_model = original_ensure
    llm.vision_model = original_vision
    llm.pick = original_pick

vision_route_check()
print("كل الاختبارات نجحت ✅")

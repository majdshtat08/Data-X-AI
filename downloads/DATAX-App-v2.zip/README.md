# DATA X

مساعد ذكاء اصطناعي شخصي مجاني يعمل على جهازك: برمجة، مواقع، تصميم، ومونتاج ريلز. صُنع بواسطة **مجد الدين شتات — رئيس Data X Team**.
A free personal AI assistant that runs on your PC: coding, websites, design and reels. Created by **Majd Al-Din Shattat — President of Data X Team**.

## ⬇ التحميل / Download
أحدث إصدار / Latest release: [**Releases → DATAX.exe**](../../releases/latest)

شغّل الملف؛ عند أول تشغيل يحاول تثبيت Ollama وFFmpeg وتنزيل نموذج الذكاء الاصطناعي المناسب. يحتاج هذا اتصال إنترنت ومساحة تخزين كافية، وقد يستغرق تنزيل النموذج وقتاً. نماذج الرؤية والصور تُنزّل عند أول استخدام لها.

Run the app; on first launch it attempts to install Ollama and FFmpeg and download a suitable AI model. Internet access and disk space are required, and model downloads may take time. The vision model is downloaded when first needed.

## المرفقات والخصوصية / Attachments & privacy
- ارفق صوراً أو فيديوهات أو ملفات نصية وPDF وWord وExcel من زر 📎. حد الرفع 8 ملفات، 20 MB لكل ملف، و40 MB إجمالاً.
- يحلل النموذج المحلي الصور وإطارات الفيديو؛ ويمكنه تنفيذ عمليات صورة وفيديو على نسخ جديدة داخل مجلد العمل. فيديوهات الرفع لا تُرسل لخدمة سحابية.
- المحادثات والملفات محفوظة محلياً في ملف المستخدم الحالي على Windows (`%APPDATA%\\DataX`) ولا تُشارك بين حسابات Windows ولا تُرفع كقاعدة محادثات مشتركة.
- يلزم اتصال بالإنترنت للتثبيت والتنزيل والبحث وتوليد الصور الواقعية. أداة توليد الصور الخارجية ترسل الوصف إلى مزودها؛ إذا تعذرت الخدمة ينشئ التطبيق غلافاً تصميمياً محلياً ويخبرك بذلك. لا تستخدمها مع وصف سري.
- PDF وDOCX وXLSX والنصوص الشائعة قابلة للاستخراج. الصيغ غير المدعومة تُحفظ محلياً ويمكن فتحها من مجلد العمل.

## للمطوّرين / For developers
- تشغيل من الكود: `START_DATAX.bat` (ويندوز) أو `python run.py`
- الاختبارات: `python tests/test_extra.py && python tests/test_attachments.py && python tests/test_all.py`
- إضافات: ضع ملف `.py` في `plugins/` · معرفة إضافية: ملفات `.md` في `knowledge/`
- الموقع: مجلد `docs/` (HTML + CSS + JS) ← GitHub Pages
- بناء exe تلقائياً: `.github/workflows/build.yml`

import base64, os, pathlib, sys, tempfile, zipfile
import urllib.error
from unittest.mock import patch

os.environ["APPDATA"] = tempfile.mkdtemp()
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from datax import attachments, config, tools
from datax.agent import Task
from pypdf import PdfWriter

upload = attachments.store_uploads([{"name": "../notes.txt", "data": base64.b64encode(b"hello from attachment").decode()}])[0]
stored = config.WORKSPACE / upload["path"]
assert stored.parent == (config.WORKSPACE / "uploads") and attachments.extract_text(stored) == "hello from attachment"

docx = config.WORKSPACE / "sample.docx"
with zipfile.ZipFile(docx, "w") as archive:
    archive.writestr("word/document.xml", '<w:document xmlns:w="urn:test"><w:p><w:r><w:t>Document text</w:t></w:r></w:p></w:document>')
assert attachments.extract_text(docx) == "Document text"

pdf = config.WORKSPACE / "sample.pdf"
writer = PdfWriter()
writer.add_blank_page(width=100, height=100)
with pdf.open("wb") as stream:
    writer.write(stream)
assert attachments.extract_text(pdf) == ""

image = attachments.store_uploads([{"name": "photo.png", "data": base64.b64encode(b"image bytes").decode()}])[0]
message = Task.__new__(Task)._user_message({"content": "describe", "attachments": [image]})
assert message["images"] == ["aW1hZ2UgYnl0ZXM="] and image["path"] in message["content"]

try:
    attachments.store_uploads([{"name": "bad.png", "data": "not-base64!"}])
    raise AssertionError("invalid base64 was accepted")
except ValueError:
    pass

failure = urllib.error.HTTPError("https://image.pollinations.ai", 503, "unavailable", {}, None)
with patch("datax.tools.urllib.request.urlopen", side_effect=failure), patch("datax.tools.make_cover", return_value="تم إنشاء صورة: local.png") as local_cover:
    fallback = tools.ai_image("blue abstract image", "fallback.png")
assert "غلافاً تصميمياً محلياً" in fallback and "HTTP 503" in fallback
local_cover.assert_called_once()

print("اختبارات المرفقات نجحت ✅")

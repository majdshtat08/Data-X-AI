"""Local attachment storage and bounded text extraction."""
import base64, binascii, pathlib, re, unicodedata, uuid, zipfile
from xml.etree import ElementTree
from .config import WORKSPACE

MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_TOTAL_SIZE = 40 * 1024 * 1024
MAX_FILES = 8
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"}
VIDEO_EXTS = {".mp4", ".mov", ".mkv", ".webm", ".avi"}
TEXT_EXTS = {
    ".txt", ".md", ".csv", ".json", ".py", ".js", ".ts", ".tsx", ".jsx",
    ".html", ".css", ".xml", ".yaml", ".yml", ".log", ".sql", ".sh", ".bat",
    ".ps1", ".ini", ".toml", ".java", ".c", ".cpp", ".h", ".cs", ".go", ".rs",
}
DOC_EXTS = {".pdf", ".docx", ".xlsx"}
MAX_ARCHIVE_MEMBER_SIZE = 100 * 1024 * 1024


def _read_member(archive, name):
    info = archive.getinfo(name)
    if info.file_size > MAX_ARCHIVE_MEMBER_SIZE:
        raise ValueError(f"الملف الداخلي {name} أكبر من الحد المسموح")
    return archive.read(name)


def store_uploads(items):
    if not isinstance(items, list) or len(items) > MAX_FILES:
        raise ValueError(f"ارفع حتى {MAX_FILES} ملفات في المرة الواحدة")
    decoded, total = [], 0
    for item in items:
        if not isinstance(item, dict) or not isinstance(item.get("name"), str) or not isinstance(item.get("data"), str):
            raise ValueError("بيانات الملف المرفق غير صالحة")
        try:
            data = base64.b64decode(item["data"], validate=True)
        except (binascii.Error, ValueError):
            raise ValueError("تعذر قراءة أحد الملفات المرفقة") from None
        if not data or len(data) > MAX_FILE_SIZE:
            raise ValueError("حجم الملف يجب أن يكون أقل من 20 ميغابايت")
        total += len(data)
        if total > MAX_TOTAL_SIZE:
            raise ValueError("الحجم الإجمالي للمرفقات يجب ألا يتجاوز 40 ميغابايت")
        name = pathlib.Path(item["name"].replace("\\", "/")).name
        name = unicodedata.normalize("NFKC", name)
        name = re.sub(r"[^\w.-]", "_", name, flags=re.UNICODE).strip("._")[:100] or "attachment"
        decoded.append((name, data))

    folder = WORKSPACE / "uploads"
    folder.mkdir(parents=True, exist_ok=True)
    result = []
    for name, data in decoded:
        path = folder / f"{uuid.uuid4().hex[:12]}_{name}"
        path.write_bytes(data)
        result.append({"name": name, "path": path.relative_to(WORKSPACE).as_posix()})
    return result


def extract_text(path, limit=12000):
    path = pathlib.Path(path)
    ext = path.suffix.lower()
    if ext in TEXT_EXTS:
        return path.read_text("utf-8", errors="replace")[:limit]
    if ext == ".docx":
        with zipfile.ZipFile(path) as archive:
            root = ElementTree.fromstring(_read_member(archive, "word/document.xml"))
        text = " ".join(node.text or "" for node in root.iter() if node.tag.endswith("}t"))
        return text[:limit]
    if ext == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError:
            raise RuntimeError("قراءة PDF تتطلب تثبيت pypdf؛ شغّل START_DATAX.bat لتثبيت مكونات التطبيق") from None
        reader = PdfReader(str(path))
        return "\n".join((page.extract_text() or "") for page in reader.pages[:30])[:limit]
    if ext == ".xlsx":
        with zipfile.ZipFile(path) as archive:
            shared = []
            if "xl/sharedStrings.xml" in archive.namelist():
                root = ElementTree.fromstring(_read_member(archive, "xl/sharedStrings.xml"))
                shared = ["".join(n.text or "" for n in item.iter() if n.tag.endswith("}t")) for item in root]
            sheets = sorted(n for n in archive.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n))
            if not sheets:
                return ""
            root = ElementTree.fromstring(_read_member(archive, sheets[0]))
        rows = []
        for row in root.iter():
            if not row.tag.endswith("}row"):
                continue
            cells = []
            for cell in row:
                if not cell.tag.endswith("}c"):
                    continue
                value = next((n.text or "" for n in cell if n.tag.endswith("}v")), "")
                if cell.attrib.get("t") == "s" and value.isdigit() and int(value) < len(shared):
                    value = shared[int(value)]
                cells.append(value)
            rows.append("\t".join(cells))
        return "\n".join(rows)[:limit]
    raise ValueError(f"صيغة الملف {ext or '(بدون امتداد)'} محفوظة، لكن لا يوجد قارئ نصي لها")

"""الأدوات. أضف أداة جديدة بملف داخل plugins/ (tool و S و P متاحة مباشرة)."""
import glob, html as H, importlib.util, os, pathlib, re, shutil, subprocess, sys, tempfile, threading, urllib.error, urllib.parse, urllib.request, webbrowser
from .config import WORKSPACE, HOME, RES, NOWIN, find_exe
REG, _tl = {}, threading.local()
def tool(name, desc, props, required=(), risky=False):
    def deco(fn):
        REG[name] = dict(fn=fn, risky=risky, schema={"name": name, "description": desc, "input_schema": {"type": "object", "properties": props, "required": list(required)}}); return fn
    return deco
S = lambda d: {"type": "string", "description": d}
I = lambda d: {"type": "integer", "description": d}
A = lambda d: {"type": "array", "items": {"type": "string"}, "description": d}
def P(p):
    p = pathlib.Path(os.path.expandvars(os.path.expanduser(str(p)))); return p if p.is_absolute() else WORKSPACE / p
def begin(): _tl.files = []
def end(): f, _tl.files = getattr(_tl, "files", []), []; return f
def produced(p):
    try: rel = pathlib.Path(p).resolve().relative_to(WORKSPACE.resolve()).as_posix()
    except ValueError: return
    if not hasattr(_tl, "files"): _tl.files = []
    if rel not in _tl.files: _tl.files.append(rel)

DANGER = re.compile(r"\b(rm|del|erase|rmdir|rd|remove-item|format|shutdown|restart-computer|reg\s+delete|taskkill|diskpart|sudo|mkfs)\b", re.I)
def needs_approval(name, args, auto=False):
    if name == "delete_path": return True
    if name == "run_command" and DANGER.search(str(args.get("command", ""))): return True
    if name == "open_target":
        t = str(args.get("target", "")); 
        if re.match(r"https?://", t): return False
        try: P(t).resolve().relative_to(WORKSPACE.resolve()); return False
        except Exception: return not auto
    return REG[name]["risky"] and not auto

# ---------- ملفات ونظام ----------
@tool("read_file", "قراءة ملف نصي", {"path": S("المسار")}, ["path"])
def read_file(path): return P(path).read_text("utf-8", errors="replace")[:30000]
@tool("write_file", "إنشاء/استبدال ملف (موقع، كود، نص...). المسار نسبي لمجلد العمل", {"path": S("المسار"), "content": S("المحتوى الكامل")}, ["path", "content"])
def write_file(path, content):
    p = P(path); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(content, "utf-8"); produced(p); return f"تمت الكتابة: {p}"
@tool("edit_file", "استبدال نص فريد داخل ملف", {"path": S("المسار"), "old": S("النص القديم"), "new": S("الجديد")}, ["path", "old", "new"])
def edit_file(path, old, new):
    p = P(path); t = p.read_text("utf-8")
    if t.count(old) != 1: return f"خطأ: النص موجود {t.count(old)} مرة (يجب مرة واحدة)"
    p.write_text(t.replace(old, new), "utf-8"); produced(p); return "تم التعديل"
@tool("list_dir", "عرض محتوى مجلد (افتراضياً مجلد العمل)", {"path": S("المسار")}, [])
def list_dir(path="."): return "\n".join(("[مجلد] " if c.is_dir() else "") + c.name for c in sorted(P(path).iterdir())) or "(فارغ)"
@tool("delete_path", "حذف ملف أو مجلد (يطلب موافقة دائماً)", {"path": S("المسار")}, ["path"], risky=True)
def delete_path(path):
    p = P(path); shutil.rmtree(p) if p.is_dir() else p.unlink(); return f"تم الحذف: {p}"
@tool("run_command", "تشغيل أمر في الطرفية (PowerShell على ويندوز)", {"command": S("الأمر")}, ["command"], risky=True)
def run_command(command):
    sh = ["powershell", "-NoProfile", "-Command", "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + command] if os.name == "nt" else ["bash", "-c", command]
    try:
        r = subprocess.run(sh, cwd=str(WORKSPACE), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=120, creationflags=NOWIN)
        return f"exit={r.returncode}\n{(r.stdout + r.stderr)[-4000:]}"
    except subprocess.TimeoutExpired: return "خطأ: انتهت المهلة (120 ثانية)"
@tool("open_target", "فتح رابط أو ملف أو برنامج (لمعاينة موقع: افتح ملف html من مجلد العمل)", {"target": S("رابط أو مسار")}, ["target"], risky=True)
def open_target(target):
    if re.match(r"https?://", target): webbrowser.open(target)
    elif os.name == "nt": os.startfile(str(P(target)) if P(target).exists() else target)
    else: subprocess.Popen(["xdg-open", str(P(target))])
    return f"تم فتح: {target}"
VK = {"ctrl": 0x11, "alt": 0x12, "shift": 0x10, "win": 0x5B, "enter": 0x0D, "tab": 0x09, "esc": 0x1B, "space": 0x20, "backspace": 0x08, "delete": 0x2E,
      "up": 0x26, "down": 0x28, "left": 0x25, "right": 0x27, "home": 0x24, "end": 0x23}
@tool("computer", "تحكم بالماوس/الكيبورد (ويندوز): click|move|type|key|scroll — x,y إحداثيات الشاشة", {"action": S("click|move|type|key|scroll"), "x": I("x"), "y": I("y"), "text": S("نص للكتابة، أو مفاتيح مثل ctrl+c")}, ["action"], risky=True)
def computer(action, x=None, y=None, text=""):
    if os.name != "nt": return "هذه الأداة تعمل على ويندوز فقط"
    import ctypes, ctypes.wintypes as w; u = ctypes.windll.user32
    if action in ("click", "move"):
        if x is None or y is None: return "حدد x و y"
        u.SetCursorPos(int(x), int(y))
        if action == "click": u.mouse_event(2, 0, 0, 0, 0); u.mouse_event(4, 0, 0, 0, 0)
    elif action == "scroll": u.mouse_event(0x800, 0, 0, int(y or -300), 0)
    elif action == "key":
        codes = [VK[k] if k in VK else (0x6F + int(k[1:]) if re.fullmatch(r"f\d+", k) else ord(k.upper())) for k in (s.strip().lower() for s in text.split("+"))]
        for c in codes: u.keybd_event(c, 0, 0, 0)
        for c in reversed(codes): u.keybd_event(c, 0, 2, 0)
    elif action == "type":
        class KI(ctypes.Structure): _fields_ = [("wVk", w.WORD), ("wScan", w.WORD), ("dwFlags", w.DWORD), ("time", w.DWORD), ("dwExtraInfo", ctypes.c_size_t)]
        class UN(ctypes.Union): _fields_ = [("ki", KI), ("pad", ctypes.c_byte * 32)]
        class IN(ctypes.Structure): _fields_ = [("type", w.DWORD), ("u", UN)]
        d = text.encode("utf-16-le"); units = [int.from_bytes(d[i:i + 2], "little") for i in range(0, len(d), 2)]; arr = (IN * (len(units) * 2))()
        for i, c in enumerate(units):
            for j, fl in enumerate((4, 6)): arr[i * 2 + j].type = 1; arr[i * 2 + j].u.ki = KI(0, c, fl, 0, 0)
        u.SendInput(len(arr), arr, ctypes.sizeof(IN))
    else: return "action غير معروف"
    return "تم"

# ---------- ويب ----------
def _get(url, n=15000):
    t = urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 DataX"}), timeout=20).read().decode("utf-8", "replace")
    return t
_clean = lambda t: re.sub(r"\s+", " ", H.unescape(re.sub(r"(?s)<(script|style).*?</\1>|<[^>]+>", " ", t))).strip()
@tool("fetch_url", "جلب نص صفحة ويب", {"url": S("الرابط")}, ["url"])
def fetch_url(url): return _clean(_get(url))[:8000]
@tool("web_search", "بحث على الإنترنت (مجاني)", {"query": S("كلمات البحث")}, ["query"])
def web_search(query):
    t = _get("https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)); out = []
    for h, ti, sn in re.findall(r'class="result__a" href="([^"]+)"[^>]*>(.*?)</a>.*?class="result__snippet"[^>]*>(.*?)</a>', t, re.S)[:6]:
        m = re.search(r"uddg=([^&]+)", h); out.append(f"- {_clean(ti)}\n  {urllib.parse.unquote(m.group(1)) if m else h}\n  {_clean(sn)}")
    return "\n".join(out) or "لا نتائج"

# ---------- صور ----------
SIZES = {"reel": (1080, 1920), "post": (1080, 1080), "youtube": (1280, 720), "story": (1080, 1920)}
def browser():
    for p in [r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
              r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"]:
        if os.path.exists(p): return p
    return next((w for n in ("msedge", "chrome", "google-chrome", "chromium", "chromium-browser") if (w := shutil.which(n))), None)
@tool("html_to_image", "تحويل صفحة HTML (تصميم/بوستر/غلاف) إلى صورة PNG بمتصفح Edge/Chrome", {"html_path": S("ملف html"), "out": S("اسم الصورة .png"), "width": I("العرض"), "height": I("الارتفاع")}, ["html_path", "out"])
def html_to_image(html_path, out="design.png", width=1080, height=1080):
    b, o = browser(), P(out)
    if not b: return "خطأ: لم أجد Edge أو Chrome"
    o.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory() as d:
        subprocess.run([b, "--headless", "--disable-gpu", "--hide-scrollbars", f"--user-data-dir={d}", f"--window-size={width},{height}",
                        "--force-device-scale-factor=1", "--virtual-time-budget=4000", f"--screenshot={o}", P(html_path).resolve().as_uri()], capture_output=True, timeout=90, creationflags=NOWIN)
    if not o.exists(): return "خطأ: فشل إنشاء الصورة"
    produced(o); return f"تم إنشاء الصورة: {o}"
THEMES = {"blue": ("#0b1d4d", "#3b82f6", "#8b5cf6"), "violet": ("#1a0b3d", "#8b5cf6", "#ec4899"), "dark": ("#05060f", "#3b82f6", "#22d3ee")}
@tool("make_cover", "تصميم غلاف/بوستر احترافي جاهز (عربي أو إنجليزي) بتدرج ألوان DATA X", {"title": S("العنوان"), "subtitle": S("سطر ثانوي"), "preset": S("reel|post|youtube|story"), "theme": S("blue|violet|dark"), "out": S("اسم الصورة .png")}, ["title"])
def make_cover(title, subtitle="", preset="post", theme="blue", out="cover.png"):
    w, h = SIZES.get(preset, SIZES["post"]); bg, c1, c2 = THEMES.get(theme, THEMES["blue"]); fs = int(min(w, h) * (0.11 if len(title) < 20 else 0.08)); e = H.escape
    page = f"""<meta charset=utf-8><style>*{{margin:0;box-sizing:border-box}}body{{width:{w}px;height:{h}px;background:radial-gradient(circle at 80% 15%,{c2}99,transparent 45%),radial-gradient(circle at 15% 90%,{c1}aa,transparent 50%),{bg};
color:#fff;font-family:'Segoe UI',Tahoma,Arial,sans-serif;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:{int(w*.08)}px;overflow:hidden}}
h1{{font-size:{fs}px;line-height:1.25;font-weight:800;text-shadow:0 8px 40px #0008}}p{{font-size:{int(fs*.4)}px;margin-top:{int(fs*.4)}px;opacity:.85}}
.b{{position:absolute;bottom:{int(h*.05)}px;font-size:{int(min(w,h)*.035)}px;letter-spacing:4px;font-weight:700;background:linear-gradient(135deg,{c1},{c2});-webkit-background-clip:text;color:transparent}}</style>
<h1 dir=auto>{e(title)}</h1><p dir=auto>{e(subtitle)}</p><div class=b>DATA X</div>"""
    tmp = WORKSPACE / ".tmp"; tmp.mkdir(exist_ok=True); f = tmp / "cover.html"; f.write_text(page, "utf-8")
    return html_to_image(str(f), out, w, h)
@tool("ai_image", "توليد صورة من الوصف عبر مزود خارجي، مع غلاف محلي بديل عند تعذر الخدمة", {"prompt": S("وصف الصورة بالإنجليزية"), "out": S("اسم الصورة .png"), "width": I("العرض"), "height": I("الارتفاع")}, ["prompt"])
def ai_image(prompt, out="ai.png", width=1024, height=1024):
    if not (128 <= int(width) <= 2048 and 128 <= int(height) <= 2048):
        return "خطأ: أبعاد الصورة يجب أن تكون بين 128 و2048"
    o = P(out)
    if o.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp"):
        return "خطأ: امتداد الصورة الناتجة يجب أن يكون PNG أو JPG أو WEBP"
    u = f"https://image.pollinations.ai/prompt/{urllib.parse.quote(prompt)}?width={width}&height={height}&nologo=true&seed={abs(hash(prompt)) % 99999}"
    try:
        with urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "DataX"}), timeout=150) as response:
            d = response.read()
        if len(d) < 2000: raise RuntimeError("الخدمة لم تُرجع صورة صالحة")
        formats = ((b"\x89PNG\r\n\x1a\n", ".png"), (b"\xff\xd8\xff", ".jpg"), (b"RIFF", ".webp"), (b"GIF8", ".gif"), (b"BM", ".bmp"))
        source_ext = next((ext for signature, ext in formats if d.startswith(signature) and (ext != ".webp" or d[8:12] == b"WEBP")), None)
        if not source_ext: raise RuntimeError("الخدمة أعادت محتوى ليس صورة مدعومة")
        o.parent.mkdir(parents=True, exist_ok=True)
        if source_ext == o.suffix.lower() or (source_ext == ".jpg" and o.suffix.lower() == ".jpeg"):
            o.write_bytes(d)
        else:
            with tempfile.TemporaryDirectory() as folder:
                src = pathlib.Path(folder) / ("source" + source_ext)
                src.write_bytes(d)
                error = ff("-i", src, "-frames:v", "1", o)
                if error: raise RuntimeError(error)
        if not o.is_file() or o.stat().st_size < 100: raise RuntimeError("تعذر حفظ الصورة الناتجة")
        produced(o); return f"تم إنشاء الصورة: {o}"
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, RuntimeError) as e:
        reason = f"HTTP {e.code}" if isinstance(e, urllib.error.HTTPError) else str(e)
        title, _, subtitle = str(prompt).partition("\n")
        if o.suffix.lower() == ".png":
            fallback = make_cover(title[:100] or "DATA X", subtitle or "تصميم محلي بديل", "post", "blue", out)
        else:
            with tempfile.TemporaryDirectory() as folder:
                cover = pathlib.Path(folder) / "cover.png"
                fallback = make_cover(title[:100] or "DATA X", subtitle or "تصميم محلي بديل", "post", "blue", str(cover))
                if not fallback.startswith("خطأ:"):
                    error = ff("-i", cover, "-frames:v", "1", o)
                    if error: fallback = f"خطأ: {error}"
                    elif not o.is_file(): fallback = "خطأ: لم يتم إنشاء ملف الصورة البديلة"
                    else: produced(o); fallback = f"تم إنشاء التصميم المحلي: {o}"
        if fallback.startswith("خطأ:"): return f"تعذر توليد الصورة عبر الخدمة الخارجية ({reason})، كما فشل الغلاف المحلي: {fallback}"
        return f"تعذر توليد صورة واقعية عبر الخدمة الخارجية ({reason})؛ أنشأت بدلاً منها غلافاً تصميمياً محلياً. {fallback}"

# ---------- فيديو ----------
def ff(*a):
    exe = find_exe("ffmpeg")
    if not exe: return "FFmpeg غير مثبت بعد. يُثبَّت تلقائياً بعد تجهيز الذكاء الاصطناعي، أو ثبّته من ffmpeg.org"
    r = subprocess.run([exe, "-y", "-hide_banner", "-loglevel", "error", *map(str, a)], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900, creationflags=NOWIN)
    return None if r.returncode == 0 else "خطأ ffmpeg: " + r.stderr[-600:]
ENC = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p"]
VF = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,fps=30,setsar=1"
@tool("make_reel", "صنع فيديو ريلز/تيك توك عمودي 9:16 من صور وفيديوهات (حركة زوم للصور) مع موسيقى اختيارية", {"items": A("مسارات صور/فيديوهات بالترتيب"), "out": S("اسم الفيديو .mp4"), "seconds_per_image": I("مدة كل صورة بالثواني"), "audio": S("ملف صوت اختياري")}, ["items"])
def make_reel(items, out="reel.mp4", seconds_per_image=3, audio=""):
    tmp = WORKSPACE / ".tmp"; tmp.mkdir(exist_ok=True); parts = []; n = int(seconds_per_image or 3) * 30
    for i, it in enumerate(items):
        src, dst = P(it), tmp / f"p{i}.mp4"
        if not src.exists(): return f"خطأ: الملف غير موجود {it}"
        if src.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp"):
            vf = f"scale=1620:2880:force_original_aspect_ratio=increase,crop=1620:2880,zoompan=z='min(zoom+0.0007,1.12)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d={n}:s=1080x1920:fps=30,setsar=1"
            e = ff("-i", src, "-vf", vf, "-t", int(seconds_per_image or 3), *ENC, "-an", dst)
        else: e = ff("-i", src, "-vf", VF, *ENC, "-an", dst)
        if e: return e
        parts.append(dst)
    lst = tmp / "list.txt"; lst.write_text("".join("file '" + p.as_posix().replace("'", "'\\''") + "'\n" for p in parts), "utf-8"); o = P(out); o.parent.mkdir(parents=True, exist_ok=True)
    e = ff("-f", "concat", "-safe", "0", "-i", lst, *(["-i", P(audio), "-shortest", "-c:v", "copy", "-c:a", "aac"] if audio else ["-c", "copy"]), o)
    if e: return e
    produced(o); return f"تم إنشاء الريلز: {o}"
@tool("video_to_reel", "تحويل فيديو أفقي إلى عمودي 9:16 (قص من المنتصف) مع الصوت", {"path": S("الفيديو"), "out": S("الناتج .mp4")}, ["path"])
def video_to_reel(path, out="reel_cut.mp4"):
    o = P(out); e = ff("-i", P(path), "-vf", VF, *ENC, "-c:a", "aac", o)
    if e: return e
    produced(o); return f"تم: {o}"
@tool("video_trim", "قص مقطع من فيديو", {"path": S("الفيديو"), "start": S("البداية مثل 00:00:05"), "end": S("النهاية مثل 00:00:12"), "out": S("الناتج .mp4")}, ["path", "start", "end"])
def video_trim(path, start, end, out="trim.mp4"):
    o = P(out); e = ff("-ss", start, "-to", end, "-i", P(path), *ENC, "-c:a", "aac", o)
    if e: return e
    produced(o); return f"تم: {o}"

@tool("edit_image", "تعديل صورة مرفقة أو من مجلد العمل: تفتيح، تغميق، تباين، تشبع، أبيض وأسود، تمويه، تدوير، عكس أو تغيير الحجم. يحفظ نسخة جديدة", {
    "path": S("مسار الصورة الأصلية"),
    "operation": S("brighten|darken|contrast|saturate|grayscale|blur|rotate90|rotate180|mirror|resize"),
    "out": S("مسار الصورة الناتجة .png أو .jpg"),
    "amount": I("قوة التعديل 1-100 (اختياري)"),
    "width": I("عرض الناتج عند resize"),
    "height": I("ارتفاع الناتج عند resize"),
}, ["path", "operation", "out"])
def edit_image(path, operation, out, amount=20, width=1080, height=1080):
    src, dst = P(path), P(out)
    if not src.is_file(): return f"خطأ: الصورة غير موجودة: {path}"
    if src.suffix.lower() not in (".png", ".jpg", ".jpeg", ".webp", ".bmp"):
        return "خطأ: صيغة صورة غير مدعومة"
    amount = max(1, min(100, int(amount or 20)))
    filters = {
        "brighten": f"eq=brightness={amount / 100:.2f}",
        "darken": f"eq=brightness=-{amount / 100:.2f}",
        "contrast": f"eq=contrast={1 + amount / 100:.2f}",
        "saturate": f"eq=saturation={1 + amount / 100:.2f}",
        "grayscale": "hue=s=0",
        "blur": f"gblur=sigma={max(1, min(20, amount / 5)):.1f}",
        "rotate90": "transpose=1",
        "rotate180": "hflip,vflip",
        "mirror": "hflip",
    }
    if operation == "resize":
        if not (64 <= int(width) <= 4096 and 64 <= int(height) <= 4096): return "خطأ: الأبعاد يجب أن تكون بين 64 و4096"
        filters[operation] = f"scale={int(width)}:{int(height)}"
    if operation not in filters: return f"خطأ: عملية تعديل غير معروفة: {operation}"
    if dst.resolve() == src.resolve(): return "خطأ: يجب حفظ الصورة المعدلة باسم مختلف عن الأصل"
    dst.parent.mkdir(parents=True, exist_ok=True)
    error = ff("-i", src, "-vf", filters[operation], "-frames:v", "1", dst)
    if error: return error
    if not dst.is_file(): return "خطأ: لم يتم إنشاء الصورة المعدلة"
    produced(dst); return f"تم تعديل الصورة وحفظ نسخة جديدة: {dst}"
@tool("ffmpeg", "أمر ffmpeg مخصص لأي مونتاج متقدم (مثال: -i a.mp4 -vf eq=brightness=0.1 b.mp4)", {"args": S("وسائط ffmpeg")}, ["args"], risky=True)
def ffmpeg_raw(args):
    import shlex; return ff(*shlex.split(args, posix=(os.name != "nt"))) or "تم"

def load_plugins(d=None):
    for dd in ([d] if d else [RES / "plugins", HOME / "plugins"]):
        for f in glob.glob(str(pathlib.Path(dd) / "*.py")):
            spec = importlib.util.spec_from_file_location(pathlib.Path(f).stem, f); m = importlib.util.module_from_spec(spec); m.tool, m.S, m.I, m.A, m.P = tool, S, I, A, P
            try: spec.loader.exec_module(m)
            except Exception as e: print("plugin error", f, e, file=sys.stderr)
def run(name, args):
    t = REG.get(name)
    if not t: return f"أداة غير موجودة: {name}"
    try: return t["fn"](**args)
    except TypeError as e: return f"خطأ في معاملات {name}: {e}"
    except Exception as e: return f"خطأ في {name}: {type(e).__name__}: {e}"

@tool("make_website", "إنشاء موقع احترافي جاهز (index.html + style.css + script.js) بتصميم عصري، عربي/إنجليزي، جاهز للنشر على GitHub Pages", {"name": S("اسم الموقع/المشروع"), "tagline": S("جملة تعريفية قصيرة"), "about": S("فقرة عن المشروع"), "features": A("المميزات، كل عنصر: عنوان|وصف"), "folder": S("اسم مجلد الموقع"), "theme": S("blue|green|orange|pink"), "lang": S("ar|en"), "contact": S("بريد أو رابط تواصل")}, ["name"])
def make_website(name, tagline="", about="", features=None, folder="site", theme="blue", lang="ar", contact=""):
    from . import webgen
    if isinstance(features, str): features = [x for x in re.split(r"[\n؛;]", features) if x.strip()]
    files = webgen.build(P(folder), name, tagline, about, features or [], theme, lang, contact)
    for f in files: produced(f)
    return f"تم إنشاء الموقع في {P(folder)} (index.html, style.css, script.js). افتحه بـ open_target ثم عدّل الملفات إن أردت."

# ---------- اختيار الأدوات حسب الطلب (يقلّل حجم الطلب فيصير الرد أسرع بكثير) ----------
GROUPS = {
 "files": (["make_website", "read_file", "write_file", "edit_file", "list_dir", "delete_path", "open_target"], r"ملف|مجلد|file|folder|اكتب|احفظ|عدّ?ل|احذف|اقرأ|كود|code|برنامج|سكربت|script|موقع|صفحة|html|site|تطبيق|لعبة|game|app"),
 "sys": (["run_command", "computer"], r"شغّ?ل|نفّ?ذ|run|launch|ماوس|mouse|keyboard|اضغط|install|ثبّ?ت|pip|python|cmd|terminal"),
 "web": (["web_search", "fetch_url"], r"ابحث|بحث|search|google|أخبار|اخبار|news|http|url|انترنت|إنترنت"),
 "img": (["make_cover", "ai_image", "edit_image", "html_to_image", "list_dir"], r"صورة|صور|غلاف|بوستر|تصميم|صمّ?م|لوغو|شعار|image|cover|poster|logo|design|thumbnail"),
 "vid": (["make_reel", "video_to_reel", "video_trim", "ffmpeg", "list_dir"], r"فيديو|ريل|مونتاج|reel|video|tiktok|تيك|قص|trim|clip|مقطع"),
}
def select(text, prev=None):
    names = []
    for ns, rx in GROUPS.values():
        if re.search(rx, text, re.I): names += [n for n in ns if n not in names]
    if not names: return list(prev or [])
    extra = [n for n in REG if not any(n in g[0] for g in GROUPS.values())]  # أدوات الإضافات
    return [n for n in names + extra if n in REG]

"""عميل Ollama: بث مباشر، اختيار تلقائي للنموذج، وتحليل أوامر الأدوات المكتوبة كنص."""
import json, os, re, shutil, subprocess, time, urllib.error, urllib.request
from . import config
BIG = ["qwen2.5:7b", "qwen3:8b", "llama3.1:8b", "qwen2.5:3b", "llama3.2:3b", "qwen2.5:1.5b"]
SMALL = ["qwen2.5:3b", "llama3.2:3b", "qwen2.5:7b", "qwen3:8b", "llama3.1:8b", "qwen2.5:1.5b"]
VISION_MODELS = ("qwen2.5vl:3b", "llava:7b", "llava:latest")
VISION_MODEL = VISION_MODELS[0]
CODER_MODELS = ("qwen2.5-coder:7b", "qwen2.5-coder:3b", "deepseek-coder:6.7b")
CODE_MODEL = CODER_MODELS[0]

def ram_gb():
    try:
        if os.name == "nt":
            import ctypes
            class M(ctypes.Structure):
                _fields_ = [("l", ctypes.c_ulong), ("p", ctypes.c_ulong), ("total", ctypes.c_ulonglong)] + [(f"x{i}", ctypes.c_ulonglong) for i in range(5)]
            m = M(); m.l = ctypes.sizeof(M); ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)); return m.total / 2**30
        return int(open("/proc/meminfo").read().split()[1]) / 2**20
    except Exception: return 8
def recommended(): return "qwen2.5:7b" if ram_gb() >= 24 else "qwen2.5:3b"
STATE, _cache = {"msg": ""}, {"t": 0, "v": None}

def _req(path, body=None, timeout=10):
    r = urllib.request.Request(config.load()["ollama_url"] + path, json.dumps(body).encode() if body is not None else None, {"Content-Type": "application/json"})
    return urllib.request.urlopen(r, timeout=timeout)
def models():
    if _cache["v"] is not None and time.time() - _cache["t"] < 3: return _cache["v"]
    try: v = [m["name"] for m in json.loads(_req("/api/tags", timeout=4).read())["models"]]
    except Exception: v = None  # None = Ollama لا يعمل
    _cache.update(t=time.time(), v=v); return v
def pick(s=None):
    s = s or config.load(); ms = models() or []
    if s["model"] != "auto": return s["model"] if s["model"] in ms else None
    local = [m for m in ms if not m.endswith(":cloud")]
    for p in (BIG if ram_gb() >= 24 else SMALL):
        if p in local: return p
    return (local or ms or [None])[0]
def warmup(model=None):
    model = model or pick()
    if model: _req("/api/generate", {"model": model, "keep_alive": "30m", "options": {"num_ctx": config.load()["ctx"]}}, 300).read()

def vision_model():
    """يرجع نموذج رؤية متاحاً فعلاً؛ وإلا يرجع الخيار الافتراضي ليُنزّل لاحقاً."""
    ms = models() or []
    for preferred in VISION_MODELS:
        if preferred in ms:
            return preferred
    for name in ms:
        if name.lower().startswith("qwen2.5vl:"):
            return name
        if name.lower().startswith(("llava:", "llava-")):
            return name
    return VISION_MODEL

def coder_model():
    ms = models() or []
    for preferred in CODER_MODELS:
        if preferred in ms:
            return preferred
    for name in ms:
        if "coder" in name.lower():
            return name
    return "qwen2.5-coder:3b" if ram_gb() < 24 else CODE_MODEL

def route_model(text, mode="auto", visual=False, settings=None):
    """اختيار نموذج حسب قسم الطلب والمرفقات، مع احترام اختيار المستخدم الثابت."""
    settings = settings or config.load()
    if settings.get("model") != "auto":
        ms = models() or []
        return settings["model"] if settings["model"] in ms else None
    if visual:
        return vision_model()
    if mode == "code":
        return coder_model()
    if mode == "media":
        return pick(settings)
    code_markers = r"(?:كود|برنامج|تطبيق|موقع|html|css|javascript|python|typescript|java|c\+\+|sql|api|bug|خطأ|دالة|function|class|github|git)"
    if re.search(code_markers, text or "", re.I):
        return coder_model()
    return pick(settings)

def stream(model, messages, schemas, system, ctx):
    body = {"model": model, "stream": True, "keep_alive": "30m", "options": {"num_ctx": ctx, "temperature": 0.3, "num_predict": 2500},
            "messages": [{"role": "system", "content": system}] + messages}
    if schemas: body["tools"] = [{"type": "function", "function": {"name": t["name"], "description": t["description"], "parameters": t["input_schema"]}} for t in schemas]
    with _req("/api/chat", body, 900) as r:
        for line in r:
            if not line.strip(): continue
            d = json.loads(line)
            if d.get("error"): raise RuntimeError(d["error"])
            yield d

def text_calls(text, known):
    """بعض النماذج تكتب أمر الأداة كنص JSON بدل الشكل الرسمي؛ نلتقطه هنا."""
    calls, clean = [], text
    for m in re.finditer(r"<tool_call>\s*(\{.*?\})\s*</tool_call>|(\{\s*\"name\"\s*:.*?\}\s*\})", text, re.S):
        try: d = json.loads(m.group(1) or m.group(2))
        except Exception: continue
        if d.get("name") in known:
            calls.append({"function": {"name": d["name"], "arguments": d.get("arguments") or d.get("parameters") or {}}}); clean = clean.replace(m.group(0), "")
    return calls, clean.strip()

NOWIN = config.NOWIN
def ensure_ollama():
    if models() is not None: return True
    exe = config.find_exe("ollama")
    if not exe: return False
    subprocess.Popen([exe, "serve"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NOWIN)
    for _ in range(40):
        time.sleep(0.5); _cache["v"] = None
        if models() is not None: return True
    return False
def winget(pid, label):
    if not shutil.which("winget"): return False
    STATE["msg"] = f"تثبيت {label} (مرة واحدة)…"
    try:
        p = subprocess.run(["winget", "install", "-e", "--id", pid, "--silent", "--accept-source-agreements", "--accept-package-agreements"], creationflags=NOWIN, timeout=1800, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if p.returncode: STATE["msg"] = f"فشل تثبيت {label}: {p.stderr[-300:] or p.stdout[-300:]}"
        return p.returncode == 0
    except Exception: return False

def ensure_model(model):
    ms = models()
    if ms is None: raise RuntimeError("محرك Ollama غير متاح؛ افتح Ollama أو أعد تشغيل DATA X")
    if model in ms: return
    exe = config.find_exe("ollama")
    if not exe: raise RuntimeError("لم أجد Ollama لتثبيت النموذج المطلوب")
    STATE["msg"] = f"تنزيل {model}…"
    try:
        p = subprocess.Popen([exe, "pull", model], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", creationflags=NOWIN)
        tail = ""
        for line in p.stdout:
            tail = line.strip()[-300:]
            matches = re.findall(r"(\d+)%", line)
            STATE["msg"] = f"تنزيل {model} {matches[-1]}%" if matches else f"تنزيل {model}…"
        code = p.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        p.kill(); p.wait(); STATE["msg"] = ""
        raise RuntimeError(f"انتهت مهلة تنزيل النموذج {model}") from None
    except Exception:
        STATE["msg"] = ""
        raise
    _cache.update(t=0, v=None)
    if code:
        STATE["msg"] = f"فشل تنزيل {model}: {tail or 'تحقق من اتصال الإنترنت ومساحة القرص'}"
        raise RuntimeError(STATE["msg"])
    if model not in (models() or []):
        STATE["msg"] = f"اكتمل التنزيل لكن النموذج {model} غير ظاهر في Ollama"
        raise RuntimeError(STATE["msg"])
    STATE["msg"] = ""
def background_setup():
    """أول تشغيل: يثبّت المتطلبات والنموذج المحدد، ويحمّله للذاكرة."""
    try:
        if not config.find_exe("ollama") and not winget("Ollama.Ollama", "محرك الذكاء الاصطناعي"):
            STATE["msg"] = "تعذّر تثبيت Ollama تلقائياً؛ ثبّته من ollama.com ثم أعد فتح DATA X"; return
        if not ensure_ollama(): STATE["msg"] = "ثبّت Ollama من ollama.com ثم أعد فتح DATA X"; return
        settings = config.load(); want = settings["model"] if settings["model"] != "auto" else recommended()
        ensure_model(want); warmup(want)
        try:
            ensure_model(vision_model())
        except Exception as e:
            print("setup vision:", e)
        try:
            ensure_model(coder_model())
        except Exception as e:
            print("setup coder:", e)
        if not config.find_exe("ffmpeg") and not winget("Gyan.FFmpeg", "FFmpeg للمونتاج"):
            STATE["msg"] = "تعذّر تثبيت FFmpeg؛ سيبقى تحليل الصور والدردشة متاحين، وثبّت FFmpeg لاستخدام الفيديو"
        else: STATE["msg"] = ""
    except Exception as e:
        if not STATE["msg"]: STATE["msg"] = f"تعذّر تجهيز التطبيق: {e}"
        print("setup failed:", str(e).encode("ascii", "replace").decode("ascii"))

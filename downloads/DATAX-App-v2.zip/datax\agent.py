import base64, json, pathlib, subprocess, tempfile, threading, urllib.error, uuid
from . import attachments, config, db, knowledge, llm, tools

SYSTEM = """أنت DATA X، مساعد شخصي على ويندوز. أجب دائماً بلغة آخر رسالة للمستخدم وباختصار؛ إذا كتب بالعربية فأجب بالعربية ولا تنتقل للغة أخرى. إذا أرسل تحية فقط، رحّب به باختصار ولا تطلب توضيحاً.
نفّذ بالأدوات مباشرة، وتحقق من النتيجة، ولا تدّعِ نجاحاً لم يحدث.
مواقع: استخدم make_website أولاً (ينشئ index.html وstyle.css وscript.js جاهزة) ثم عدّلها إن لزم ثم open_target. غلاف: make_cover. صورة: ai_image بوصف إنجليزي. ريلز: make_reel.
لا تكشف كلمات المرور. الحذف والأوامر الخطيرة تحتاج موافقة المستخدم. مجلد العمل: {ws}"""
PREV = {}

class Task:
    def __init__(self, chat, text, files=None):
        self.chat, self.text, self.files, self.events, self.pending = chat, text, files or [], [], {}
        self.cv, self.done, self.cancel = threading.Condition(), False, False
        threading.Thread(target=self._run, daemon=True).start()

    def emit(self, type, **kw):
        with self.cv: self.events.append({"i": len(self.events), "type": type, **kw}); self.cv.notify_all()

    def approve(self, cid, ok):
        ev = self.pending.get(cid)
        if ev: ev["ok"] = ok; ev["e"].set()

    def _ask(self, cid, name, args):
        ev = self.pending[cid] = {"e": threading.Event(), "ok": False}
        self.emit("approval", id=cid, name=name, input=args)
        ev["e"].wait(300); self.pending.pop(cid, None); return ev["ok"]

    def _run(self):
        try: self._loop()
        except urllib.error.URLError: self.emit("error", text="Ollama غير شغال. افتح برنامج Ollama (أو شغّل START_DATAX.bat) ثم أعد المحاولة.")
        except Exception as e: self.emit("error", text=f"{type(e).__name__}: {e}")
        finally:
            with self.cv: self.done = True; self.cv.notify_all()

    def _exec(self, name, args):
        cid = uuid.uuid4().hex[:8]; self.emit("tool", name=name, input=args)
        if name in tools.REG and tools.needs_approval(name, args, config.load()["auto_approve"]) and not self._ask(cid, name, args):
            self.emit("result", name=name, text="رُفضت العملية", files=[]); return "رفض المستخدم تنفيذ هذه العملية."
        tools.begin(); out = str(tools.run(name, args)); files = tools.end()
        self.emit("result", name=name, text=out[:400], files=files); return out

    def _video_images(self, path):
        exe = config.find_exe("ffmpeg")
        if not exe: raise RuntimeError("فهم الفيديو يتطلب FFmpeg؛ شغّل START_DATAX.bat أو ثبّته من ffmpeg.org")
        with tempfile.TemporaryDirectory() as folder:
            pattern = pathlib.Path(folder) / "frame-%02d.jpg"
            command = [exe, "-hide_banner", "-loglevel", "error", "-i", str(path), "-vf", "fps=1/3,scale=768:-1", "-frames:v", "4", str(pattern)]
            result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=180, creationflags=config.NOWIN)
            frames = sorted(pathlib.Path(folder).glob("frame-*.jpg"))
            if result.returncode or not frames:
                raise RuntimeError("تعذر استخراج إطارات من الفيديو: " + result.stderr[-300:])
            return [base64.b64encode(frame.read_bytes()).decode("ascii") for frame in frames]

    def _user_message(self, content):
        if isinstance(content, str): return {"role": "user", "content": content}
        text = content.get("content", "")
        images = []
        for item in content.get("attachments", []):
            path = (config.WORKSPACE / item["path"]).resolve()
            try: path.relative_to(config.WORKSPACE.resolve())
            except ValueError: raise RuntimeError("مسار المرفق خارج مجلد العمل")
            ext = path.suffix.lower()
            if not path.is_file(): raise RuntimeError(f"تعذر العثور على المرفق: {item['name']}")
            if ext in attachments.IMAGE_EXTS:
                images.append(base64.b64encode(path.read_bytes()).decode("ascii"))
                text += f"\n[صورة مرفقة: {item['name']}؛ مسارها داخل مجلد العمل: {item['path']}]"
            elif ext in attachments.VIDEO_EXTS:
                images.extend(self._video_images(path))
                text += f"\n[إطارات مستخرجة من الفيديو المرفق: {item['name']}؛ مساره داخل مجلد العمل: {item['path']}]"
            elif ext in attachments.TEXT_EXTS or ext in attachments.DOC_EXTS:
                extracted = attachments.extract_text(path)
                text += f"\n\n[محتوى الملف {item['name']}]\n{extracted}\n[نهاية الملف]"
            else:
                text += f"\n[مرفق محفوظ في مجلد العمل: {item['path']}؛ الصيغة غير مدعومة للقراءة التلقائية]"
        message = {"role": "user", "content": text}
        if images: message["images"] = images
        return message

    def _loop(self):
        s = config.load()
        self.text = self.text or "حلّل المرفقات واشرح محتواها، أو نفّذ المطلوب عليها."
        db.add(self.chat, "user", {"content": self.text, "attachments": self.files} if self.files else self.text)
        history = db.load(self.chat)[-10:]
        msgs = []
        for item in history:
            if item["role"] == "tool": continue
            content = item["content"]
            if item["role"] == "user": msgs.append(self._user_message(content))
            elif isinstance(content, dict): msgs.append({"role": item["role"], **content})
            else: msgs.append({"role": item["role"], "content": content})
        while msgs and msgs[0]["role"] != "user": msgs.pop(0)
        visual = any(m.get("images") for m in msgs)
        if llm.models() is None: raise urllib.error.URLError("down")
        if visual:
            llm.ensure_model(llm.VISION_MODEL); model = llm.VISION_MODEL
        else:
            model = llm.pick(s)
        if not model:
            status = llm.STATE["msg"]
            if status:
                if status.startswith(("فشل", "تعذّر", "تعذر")): raise RuntimeError(status)
                raise RuntimeError("انتظر حتى يكتمل تجهيز النموذج: " + status)
            wanted = s["model"] if s["model"] != "auto" else llm.recommended()
            raise RuntimeError(f"النموذج {wanted} غير منزّل. أعد تشغيل DATA X لتنزيله أو اختر نموذجاً متاحاً من الإعدادات.")
        attachment_names = " ".join(item["name"] for item in self.files)
        names = tools.select(self.text + " " + attachment_names, PREV.get(self.chat)); PREV[self.chat] = names
        schemas = [tools.REG[n]["schema"] for n in names]; use_tools = bool(schemas)
        k = knowledge.lookup(self.text); sysmsg = SYSTEM.format(ws=config.WORKSPACE) + (("\n\n# مراجع\n" + k) if k else "")
        for _ in range(s["max_steps"]):
            if self.cancel: return self.emit("error", text="تم الإيقاف")
            text, calls = "", []
            try:
                for d in llm.stream(model, msgs, schemas if use_tools else None, sysmsg, s["ctx"]):
                    m = d.get("message", {})
                    if m.get("content"): text += m["content"]; self.emit("token", text=m["content"])
                    calls += m.get("tool_calls") or []
                    if d.get("eval_count") and d.get("eval_duration"): self.emit("stats", text=f"{d['eval_count'] / d['eval_duration'] * 1e9:.1f} tok/s · {model}")
            except urllib.error.HTTPError as e:
                body = e.read().decode("utf-8", "replace")
                if e.code == 404: raise RuntimeError(f"النموذج {model} غير منزّل. نفّذ: ollama pull {model}")
                if use_tools and "tool" in body.lower(): use_tools = False; self.emit("notice", text="هذا النموذج لا يدعم الأدوات، سأجيب بالنص فقط."); continue
                raise RuntimeError(f"Ollama {e.code}: {body[:300]}")
            if use_tools and not calls:
                calls, clean = llm.text_calls(text, tools.REG)
                if calls: text = clean; self.emit("replace", text=clean)
            a = {"content": text}
            if calls: a["tool_calls"] = calls
            msgs.append({"role": "assistant", **a}); db.add(self.chat, "assistant", a); self.emit("msg_end")
            if not calls: return self.emit("final")
            for c in calls:
                f = c["function"]; args = f.get("arguments") or {}
                if isinstance(args, str):
                    try: args = json.loads(args)
                    except Exception: args = {}
                out = self._exec(f["name"], args if isinstance(args, dict) else {})[:2000]
                msgs.append({"role": "tool", "tool_name": f["name"], "content": out}); db.add(self.chat, "tool", {"tool_name": f["name"], "content": out})
        self.emit("error", text="وصلت للحد الأقصى من الخطوات. اكتب «أكمل» للمتابعة.")

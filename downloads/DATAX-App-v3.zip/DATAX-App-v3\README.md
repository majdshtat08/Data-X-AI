# DATA X

مساعد ذكاء اصطناعي شخصي مجاني يعمل على جهازك: برمجة، مواقع، تصميم، ومونتاج ريلز. صُنع بواسطة **مجد الدين شتات — رئيس Data X Team**.
A free personal AI assistant that runs on your PC: coding, websites, design and reels. Created by **Majd Al-Din Shattat — President of Data X Team**.

## ⬇ التحميل / Download
أحدث إصدار / Latest release: [**Releases → DATAX.exe**](../../releases/latest)

شغّل الملف؛ عند أول تشغيل يحاول تثبيت Ollama وFFmpeg وتنزيل نموذج الذكاء الاصطناعي المناسب. يحتاج هذا اتصال إنترنت ومساحة تخزين كافية، وقد يستغرق تنزيل النموذج وقتاً. نماذج الرؤية والصور تُنزّل عند أول استخدام لها.

شغّل الملف؛ عند أول تشغيل يجهز DATA X تلقائياً المكونات المطلوبة ويخطط لتنزيل موديلات الأقسام:
- البرمجة والمواقع والتطبيقات: `qwen2.5-coder:1.5b`
- المحادثة والتخطيط والتلخيص: `smollm2:1.7b`
- الرؤية والصور عند الحاجة: `qwen2.5vl:3b`
- الأدوات المحلية: Ollama وFFmpeg وKdenlive

Run the app; on first launch DATA X prepares the local runtime and downloads the section models: Qwen2.5-Coder 1.5B for coding, SmolLM2 1.7B for chat/planning, and Qwen2.5-VL for visual tasks. Ollama, FFmpeg and Kdenlive are also prepared automatically. Internet access and disk space are required.

## المرفقات والخصوصية / Attachments & privacy
- ارفق صوراً أو فيديوهات أو ملفات نصية وPDF وWord وExcel من زر 📎. حد الرفع 8 ملفات، 20 MB لكل ملف، و40 MB إجمالاً.
- يحلل النموذج المحلي الصور وإطارات الفيديو؛ ويمكنه تنفيذ عمليات صورة وفيديو على نسخ جديدة داخل مجلد العمل. فيديوهات الرفع لا تُرسل لخدمة سحابية.
- المحادثات والملفات محفوظة محلياً في ملف المستخدم الحالي على Windows (`%APPDATA%\\DataX`) ولا تُشارك بين حسابات Windows ولا تُرفع كقاعدة محادثات مشتركة.
- يلزم اتصال بالإنترنت للتثبيت والتنزيل والبحث وتوليد الصور الواقعية. أداة توليد الصور الخارجية ترسل الوصف إلى مزودها؛ إذا تعذرت الخدمة ينشئ التطبيق غلافاً تصميمياً محلياً ويخبرك بذلك. لا تستخدمها مع وصف سري.
- PDF وDOCX وXLSX والنصوص الشائعة قابلة للاستخراج. الصيغ غير المدعومة تُحفظ محلياً ويمكن فتحها من مجلد العمل.

## للمطوّرين / For developers
- تشغيل من الكود: `START_DATAX.bat` (ويندوز) أو `python run.py`
- الاختبارات: `python tests/test_extra.py && python tests/test_attachments.py && python tests/test_all.py`
- إضافات: ضع ملف `.py` في `plugins/` · معرفة إضافية: ملفات `.md` في `knowledge/`
- الموقع: مجلد `docs/` (HTML + CSS + JS) ← GitHub Pages
- بناء exe تلقائياً: `.github/workflows/build.yml`
